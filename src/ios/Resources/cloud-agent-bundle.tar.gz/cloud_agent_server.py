#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OpenMinis Cloud Computer & Agent Service (cloud_agent_server.py) v2.0
- Full model dialogue and tool history persistence (tool_calls, tool results)
- Monotonic event cursor (id monotone, GET /v1/tasks/{id}/events?after=...)
- Client nonce idempotency (POST /v1/sessions/{id}/messages)
- Stable session mapping via local_session_id (POST /v1/sessions/import)
- Transactional task and message creation before ACK
- Process-memory API keys (survives client disconnection)
- Distinct status states: queued, running, completed, waiting_user, failed, cancelled, limit_reached, interrupted
- Integrated Playwright Chromium browser tools with persistent per-workspace profile
- Integrated X11 desktop computer tools (scrot, xdotool)
- Workspace attachments endpoint with Bearer auth (/v1/sessions/{id}/attachments/{filename})
- Encrypted provider credential store (AES-256-GCM, /v1/credentials; names only are ever listed)
- Approval cards: risky tool calls pause the task in waiting_user until the user approves or denies
- Routines: cron / interval / once saved prompts run by a scheduler thread with stored encrypted credentials
- Structured memory: memory_write / memory_search over SQLite FTS5 (trigram), shared Markdown format with the phone
- Skills lazy-load: only a name + description index goes into the prompt; skill_load reads the full SKILL.md
- Push: Bark / ntfy notifications on task completion, approvals and routine runs (config stored encrypted)
- Pages library (page_write), cloud sub agents (subagent_task) and image generation (image_generate)
- Telegram channel: Bot API long polling, per-chat sessions, inline approve/deny buttons
- Personas: several bots with their own instructions and memory scope, usable from chat, routines and Telegram
"""

import os
import sys
import json
import sqlite3
import time
import uuid
import signal
import subprocess
import threading
import tempfile
import mimetypes
import urllib.request
import urllib.error
import urllib.parse
import hashlib
from urllib.parse import urlparse, parse_qs, unquote
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

# Import sub-modules
SERVER_DIR = os.path.dirname(os.path.abspath(__file__))
if SERVER_DIR not in sys.path:
    sys.path.insert(0, SERVER_DIR)

import re
import cloud_browser
import cloud_delegation as deleg
import cloud_groups
import cloud_desktop
import cloud_secrets
import cloud_policy
import cloud_cron
import cloud_memory
import cloud_skills
import cloud_notify
import cloud_pages
import cloud_telegram
import cloud_bots
import cloud_plugins
import cloud_mcp
import cloud_deps
import cloud_isolation as iso
import cloud_displays

HOST = os.environ.get("OPENMINIS_HOST", "127.0.0.1")
PORT = int(os.environ.get("OPENMINIS_PORT", "18765"))
BASE_DIR = os.path.abspath(os.environ.get("OPENMINIS_BASE", SERVER_DIR))
DB_PATH = os.environ.get("OPENMINIS_DB", os.path.join(BASE_DIR, "data", "openminis_agent.db"))
GLOBAL_WORKSPACE = os.path.abspath(os.environ.get("OPENMINIS_WORKSPACE", os.path.join(BASE_DIR, "workspace")))
TOKEN_FILE = os.environ.get("OPENMINIS_TOKEN_FILE", "/etc/openminis/token")
MAX_TURNS = int(os.environ.get("OPENMINIS_MAX_TURNS", "128"))

def validate_and_load_token():
    token = os.environ.get("OPENMINIS_TOKEN")
    if token:
        return token.strip()
    if not os.path.exists(TOKEN_FILE):
        sys.stderr.write(f"[-] CRITICAL ERROR: Token file not found at {TOKEN_FILE} and OPENMINIS_TOKEN not set.\n")
        sys.exit(1)
    try:
        st = os.stat(TOKEN_FILE)
        if not (st.st_mode & 0o077) == 0:
            sys.stderr.write("[-] CRITICAL ERROR: Token file permissions must be 600.\n")
            sys.exit(1)
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            t = f.read().strip()
            if not t:
                raise ValueError("Empty token")
            return t
    except Exception as e:
        sys.stderr.write(f"[-] CRITICAL ERROR: Token load failed: {e}\n")
        sys.exit(1)

SERVER_TOKEN = None

os.makedirs(os.path.dirname(os.path.abspath(DB_PATH)), exist_ok=True)
os.makedirs(GLOBAL_WORKSPACE, exist_ok=True)

def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA busy_timeout=30000;")
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Sessions table with local_session_id mapping
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sessions (
        session_id TEXT PRIMARY KEY,
        local_session_id TEXT UNIQUE,
        title TEXT,
        instructions TEXT,
        created_at REAL
    )
    """)
    
    # Messages table storing role, content, tool_calls, tool_call_id
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        role TEXT,
        content TEXT,
        tool_calls TEXT,
        tool_call_id TEXT,
        timestamp REAL
    )
    """)
    
    # Tasks table with client_nonce idempotency
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS tasks (
        task_id TEXT PRIMARY KEY,
        session_id TEXT,
        client_nonce TEXT UNIQUE,
        status TEXT,
        model TEXT,
        created_at REAL
    )
    """)

    # Task events table with monotonic autoincrement ID
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS task_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id TEXT,
        event_type TEXT,
        payload TEXT,
        timestamp REAL
    )
    """)

    # 兼容build9/10已有数据库；CREATE IF NOT EXISTS不会为旧表添加列。
    migrations = {
        'sessions': {'local_session_id': 'TEXT', 'instructions': 'TEXT', 'persona_id': 'TEXT'},
        'messages': {'tool_calls': 'TEXT', 'tool_call_id': 'TEXT'},
        'tasks': {'client_nonce': 'TEXT'},
    }
    for table, columns in migrations.items():
        existing_columns = {row[1] for row in cursor.execute('PRAGMA table_info(' + table + ')')}
        for column, kind in columns.items():
            if column not in existing_columns:
                cursor.execute('ALTER TABLE ' + table + ' ADD COLUMN ' + column + ' ' + kind)
    cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_sessions_local ON sessions(local_session_id) WHERE local_session_id IS NOT NULL')
    cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_nonce ON tasks(client_nonce) WHERE client_nonce IS NOT NULL')
    # 等待审批 (waiting_user) 的任务同样占用会话，同会话只允许一个活动任务
    cursor.execute("DROP INDEX IF EXISTS idx_tasks_session_running")
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_session_active ON tasks(session_id) WHERE status IN ('running', 'waiting_user')")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_session ON tasks(session_id, created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_task_events_task ON task_events(task_id, id)")

    # 加密凭据：api_key 仅以 AES-GCM 密文落盘，AAD 绑定凭据名
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS credentials (
        name TEXT PRIMARY KEY,
        protocol TEXT,
        base_url TEXT,
        ciphertext BLOB NOT NULL,
        key_hint TEXT,
        created_at REAL,
        updated_at REAL
    )
    """)
    
    # 风险操作审批记录
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS approvals (
        approval_id TEXT PRIMARY KEY,
        task_id TEXT,
        tool_call_id TEXT,
        tool TEXT,
        arguments TEXT,
        rule_id TEXT,
        category TEXT,
        reason TEXT,
        status TEXT,
        note TEXT,
        created_at REAL,
        expires_at REAL,
        decided_at REAL
    )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_approvals_task ON approvals(task_id, created_at)")

    # 云端例行任务与运行记录
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS routines (
        routine_id TEXT PRIMARY KEY,
        name TEXT,
        prompt TEXT,
        schedule TEXT,
        credential TEXT,
        model TEXT,
        instructions TEXT,
        enabled INTEGER,
        max_runs INTEGER,
        run_count INTEGER DEFAULT 0,
        next_run_at REAL,
        last_run_at REAL,
        last_status TEXT,
        notify INTEGER DEFAULT 1,
        created_at REAL,
        updated_at REAL
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS routine_runs (
        run_id TEXT PRIMARY KEY,
        routine_id TEXT,
        task_id TEXT,
        session_id TEXT,
        trigger TEXT,
        status TEXT,
        result TEXT,
        error TEXT,
        started_at REAL,
        finished_at REAL
    )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_routine_runs ON routine_runs(routine_id, started_at)")
    routine_cols = {row[1] for row in cursor.execute("PRAGMA table_info(routines)")}
    if "persona_id" not in routine_cols:
        cursor.execute("ALTER TABLE routines ADD COLUMN persona_id TEXT")
    if "reasoning_effort" not in routine_cols:
        cursor.execute("ALTER TABLE routines ADD COLUMN reasoning_effort TEXT")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS personas (
        persona_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        instructions TEXT NOT NULL,
        emoji TEXT,
        created_at REAL,
        updated_at REAL
    )
    """)

    # 结构化记忆（FTS5 trigram，不可用时退化为 LIKE）
    cursor.execute(deleg.SCHEMA)
    conn.commit()
    cloud_groups.ensure_schema(conn)
    cloud_memory.ensure_schema(conn)
    cloud_skills.ensure_schema(conn)
    cloud_bots.ensure_schema(conn)
    cloud_plugins.ensure_schema(conn)
    conn.execute("CREATE TABLE IF NOT EXISTS app_settings (name TEXT PRIMARY KEY, value TEXT)")
    try:
        row = conn.execute("SELECT value FROM app_settings WHERE name = 'timezone'").fetchone()
        cloud_memory.set_timezone(row[0] if row else None)
    except Exception as e:
        print(f"timezone setting ignored: {e}")
    cloud_notify.ensure_schema(conn)
    cloud_pages.ensure_schema(conn)
    cursor.execute("CREATE TABLE IF NOT EXISTS telegram_chats (chat_id INTEGER PRIMARY KEY, session_id TEXT, updated_at REAL)")
    cursor.execute("CREATE TABLE IF NOT EXISTS telegram_tasks (task_id TEXT PRIMARY KEY, chat_id INTEGER, created_at REAL)")
    cursor.execute("CREATE TABLE IF NOT EXISTS telegram_state (key TEXT PRIMARY KEY, value TEXT)")
    cursor.execute("CREATE TABLE IF NOT EXISTS telegram_bot_chats (channel TEXT NOT NULL, chat_id INTEGER NOT NULL, session_id TEXT, updated_at REAL, PRIMARY KEY (channel, chat_id))")
    if "channel" not in {row[1] for row in cursor.execute("PRAGMA table_info(telegram_tasks)")}:
        cursor.execute("ALTER TABLE telegram_tasks ADD COLUMN channel TEXT NOT NULL DEFAULT ''")

    # Server restart: mark interrupted
    cursor.execute("UPDATE tasks SET status = 'interrupted' WHERE status IN ('running', 'queued', 'waiting_user')")
    cursor.execute("UPDATE approvals SET status = 'expired', decided_at = ? WHERE status = 'pending'", (time.time(),))
    cursor.execute("UPDATE routine_runs SET status = 'interrupted', finished_at = ? WHERE status IN ('running', 'waiting_user')", (time.time(),))
    conn.commit()
    conn.close()

init_db()

active_tasks = {}
active_tasks_lock = threading.Lock()

def set_task_cancelled(task_id):
    with active_tasks_lock:
        if task_id in active_tasks:
            active_tasks[task_id]["cancelled"] = True
            proc = active_tasks[task_id].get("process")
            if proc and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass
        else:
            active_tasks[task_id] = {"process": None, "cancelled": True, "pid": None}

def is_task_cancelled(task_id):
    """子代理、被委托的 Bot 任务随上游任务一起取消（沿 parent 链向上最多 12 层）。"""
    with active_tasks_lock:
        seen = 0
        while task_id and seen < 12:
            entry = active_tasks.get(task_id, {})
            if entry.get("cancelled", False):
                return True
            task_id = entry.get("parent")
            seen += 1
        return False

SHARED_WORKSPACE = os.path.join(GLOBAL_WORKSPACE, "shared")
ACTIVE_SLOTS = {}   # session_id -> 同一 Bot 的并发槽（>0 时用独立子工作区 / 屏幕）

def get_session_workspace(session_id):
    """Bot 会话用 Bot 自己的工作区 workspace/bots/<id>/workspace（并发槽 k>0 用 bots/<id>/slots/<k>）；
    旧会话已有 workspace/<session_id> 目录时继续用，升级不丢文件。"""
    legacy = os.path.join(GLOBAL_WORKSPACE, session_id)
    ws = legacy
    if not os.path.isdir(legacy):
        try:
            pid = session_persona_id(session_id)
        except Exception:
            pid = None
        if pid and re.match(r"^[a-z0-9][a-z0-9_-]{0,31}$", pid):
            slot = ACTIVE_SLOTS.get(session_id, 0)
            ws = os.path.join(GLOBAL_WORKSPACE, "bots", pid, "workspace" if not slot else os.path.join("slots", str(slot)))
    os.makedirs(ws, exist_ok=True)
    return ws

def safe_path_resolve(session_id, user_path):
    ws = get_session_workspace(session_id)
    if not user_path:
        return None, "Missing path"
    if user_path == "@shared" or user_path.startswith("@shared/"):
        # 所有 Bot 共用的交换目录
        os.makedirs(SHARED_WORKSPACE, exist_ok=True)
        ws, user_path = SHARED_WORKSPACE, user_path[len("@shared"):].lstrip("/") or "."
    try:
        joined = os.path.join(ws, user_path)
        real_target = os.path.realpath(joined)
        real_ws = os.path.realpath(ws)
        if os.path.commonpath([real_target, real_ws]) != real_ws:
            return None, "Access denied: path outside session workspace"
        return real_target, None
    except Exception as e:
        return None, str(e)

def validate_base_url(url_str):
    if not isinstance(url_str, str) or not url_str.strip():
        return False, "Invalid base_url: must be non-empty string"
    try:
        p = urlparse(url_str)
        if p.scheme not in ("http", "https") or not p.netloc:
            return False, "Invalid base_url: invalid scheme or host"
        if p.username or p.password or p.fragment:
            return False, "Invalid base_url: credentials or fragment not allowed"
        return True, ""
    except Exception as e:
        return False, f"Invalid base_url: {e}"

def sanitize_err(e):
    import re
    s = str(e)
    s = re.sub(r'sk-[a-zA-Z0-9\-_]{20,}', 'sk-***REDACTED***', s)
    s = re.sub(r'Bearer\s+[a-zA-Z0-9\-_.\s]+', 'Bearer ***REDACTED***', s)
    return s

CREDENTIAL_NAME_RE = re.compile(r'^[A-Za-z0-9_.:-]{1,64}$')

def credential_aad(name):
    return "credential:" + name

def credential_hint(api_key):
    # 只保留末 4 位便于用户辨认，短 Key 不显示任何字符
    return ("…" + api_key[-4:]) if len(api_key) >= 12 else "…"

def put_credential(name, api_key, base_url, protocol="chat"):
    box = cloud_secrets.get_box()
    blob = box.encrypt(api_key, credential_aad(name))
    now = time.time()
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT created_at FROM credentials WHERE name = ?", (name,))
        row = c.fetchone()
        if row:
            c.execute("UPDATE credentials SET protocol = ?, base_url = ?, ciphertext = ?, key_hint = ?, updated_at = ? WHERE name = ?",
                      (protocol, base_url, blob, credential_hint(api_key), now, name))
        else:
            c.execute("INSERT INTO credentials (name, protocol, base_url, ciphertext, key_hint, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                      (name, protocol, base_url, blob, credential_hint(api_key), now, now))
        conn.commit()
        return not bool(row)
    finally:
        conn.close()

def delete_credential(name):
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("DELETE FROM credentials WHERE name = ?", (name,))
        conn.commit()
        return c.rowcount > 0
    finally:
        conn.close()

def list_credentials():
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT name, protocol, base_url, key_hint, created_at, updated_at FROM credentials ORDER BY name ASC")
        return [{"name": r[0], "protocol": r[1], "base_url": r[2], "key_hint": r[3], "created_at": r[4], "updated_at": r[5]} for r in c.fetchall()]
    finally:
        conn.close()

def load_credential(name):
    """返回 {"protocol","base_url","api_key"}；不存在返回 None。解密失败抛 SecretDecryptError。"""
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT protocol, base_url, ciphertext FROM credentials WHERE name = ?", (name,))
        row = c.fetchone()
    finally:
        conn.close()
    if not row:
        return None
    api_key = cloud_secrets.get_box().decrypt(row[2], credential_aad(name))
    return {"protocol": row[0] or "chat", "base_url": row[1], "api_key": api_key}

def resolve_provider(provider):
    """把请求里的 provider 规范为 {"protocol","base_url","api_key"}。
    provider.credential 指向已加密保存的凭据；否则沿用请求内存中的 api_key。
    返回 (provider_config, http_status, error)。"""
    if not isinstance(provider, dict):
        return None, 400, "provider must be a dictionary"
    protocol = provider.get("protocol", "chat")
    if not isinstance(protocol, str) or protocol != "chat":
        return None, 400, "Unsupported provider protocol. Only 'chat' is supported."
    cred_name = provider.get("credential")
    if cred_name is not None:
        if not isinstance(cred_name, str) or not CREDENTIAL_NAME_RE.match(cred_name):
            return None, 400, "Invalid credential name"
        try:
            stored = load_credential(cred_name)
        except cloud_secrets.SecretStoreUnavailable as e:
            return None, 503, "Credential store unavailable: " + str(e)
        except cloud_secrets.SecretDecryptError as e:
            return None, 409, str(e)
        if not stored:
            return None, 404, "Credential not found: " + cred_name
        base_url = provider.get("base_url") or stored.get("base_url") or "https://api.openai.com/v1"
        ok, err = validate_base_url(base_url)
        if not ok:
            return None, 400, err
        return {"protocol": "chat", "base_url": base_url, "api_key": stored["api_key"], "credential": cred_name}, 200, None
    api_key = provider.get("api_key", "")
    if not isinstance(api_key, str):
        return None, 400, "api_key must be a string"
    base_url = provider.get("base_url", "https://api.openai.com/v1")
    ok, err = validate_base_url(base_url)
    if not ok:
        return None, 400, err
    return {"protocol": "chat", "base_url": base_url, "api_key": api_key}, 200, None

ACTIVE_TASK_STATUSES = ("running", "waiting_user")

def approval_policy_path():
    return os.environ.get("OPENMINIS_APPROVAL_POLICY_FILE",
                          os.path.join(os.path.dirname(os.path.abspath(DB_PATH)), "approval_policy.json"))

def current_approval_policy():
    return cloud_policy.load_policy(approval_policy_path())

# approval_id -> {"event": threading.Event, "decision": str|None, "note": str|None, "task_id": str}
pending_approvals = {}
pending_approvals_lock = threading.Lock()

def current_notify_config():
    """解密推送配置；未配置或加密存储不可用时返回 None。"""
    conn = get_db_connection()
    try:
        return cloud_notify.load(conn)
    except Exception as e:
        print(f"notify config unavailable: {type(e).__name__}")
        return None
    finally:
        conn.close()

def muted_bots():
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT value FROM app_settings WHERE name = 'notify_muted_bots'").fetchone()
        return set(json.loads(row[0])) if row else set()
    except Exception:
        return set()
    finally:
        conn.close()

def set_bot_notify(bot_id, enabled):
    muted = muted_bots()
    if enabled:
        muted.discard(bot_id)
    else:
        muted.add(bot_id)
    conn = get_db_connection()
    try:
        conn.execute("INSERT INTO app_settings (name, value) VALUES ('notify_muted_bots', ?) ON CONFLICT(name) DO UPDATE SET value = excluded.value",
                     (json.dumps(sorted(muted)),))
        conn.commit()
    finally:
        conn.close()

def _bot_muted(session_id=None, persona_id=None):
    """该会话（或例行任务）所属 Bot 关闭了推送时返回 True。"""
    pid = persona_id if persona_id is not None else (session_persona_id(session_id) if session_id else None)
    return bool(pid) and pid in muted_bots()

def bot_library(bot_id, limit=300):
    """Bot 对话里出现过的图片、链接与生成的页面（资料库）。"""
    conn = get_db_connection()
    try:
        sids = [r[0] for r in conn.execute("SELECT session_id FROM sessions WHERE persona_id = ?", (bot_id,)).fetchall()]
        if not sids:
            return []
        marks = ",".join("?" * len(sids))
        rows = conn.execute(f"SELECT id, session_id, role, content, timestamp FROM messages WHERE session_id IN ({marks}) "
                            f"AND role IN ('user', 'assistant') AND content IS NOT NULL ORDER BY id DESC LIMIT 2000", sids).fetchall()
        pages = conn.execute(f"SELECT page_id, title, summary, session_id, updated_at FROM pages WHERE session_id IN ({marks}) ORDER BY updated_at DESC LIMIT 200", sids).fetchall()
    finally:
        conn.close()
    items, seen_links = [], set()
    for mid, sid, role, content, ts in rows:
        text = content
        parts = None
        if content.startswith("["):
            try:
                parts = json.loads(content)
            except ValueError:
                parts = None
        if isinstance(parts, list):
            text = " ".join(p.get("text", "") for p in parts if isinstance(p, dict) and p.get("type") == "text")
            for idx, p in enumerate(parts):
                if isinstance(p, dict) and p.get("type") == "image_url":
                    items.append({"kind": "media", "id": f"m{mid}-{idx}", "message_id": mid, "part": idx, "session_id": sid,
                                  "role": role, "title": "图片", "at": ts})
        for url in re.findall(r"https?://[^\s<>\"'）)\]，。]+", text or ""):
            url = url.rstrip(".,;:!?")
            if url in seen_links:
                continue
            seen_links.add(url)
            host = urllib.parse.urlparse(url).hostname or url
            items.append({"kind": "link", "id": "l" + hashlib.sha256(url.encode()).hexdigest()[:16], "url": url,
                          "title": host, "session_id": sid, "role": role, "at": ts})
    for sid in sids:
        adir = os.path.join(get_session_workspace(sid), "attachments")
        if not os.path.isdir(adir):
            continue
        for name in os.listdir(adir):
            if not name.startswith("up_"):
                continue  # 只收手机上传的附件；Agent 截图不进资料库
            full = os.path.join(adir, name)
            ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
            items.append({"kind": "media" if ext in ("png", "jpg", "jpeg", "heic", "gif", "webp", "mov", "mp4") else "file",
                          "id": "a" + hashlib.sha256((sid + name).encode()).hexdigest()[:16], "title": name[12:] or name,
                          "attachment_url": f"/v1/sessions/{sid}/attachments/{name}", "bytes": os.path.getsize(full),
                          "session_id": sid, "at": os.path.getmtime(full)})
    for pid, title, summary, sid, ts in pages:
        items.append({"kind": "file", "id": "p" + pid, "page_id": pid, "title": title, "summary": summary or "", "session_id": sid, "at": ts})
    items.sort(key=lambda i: i.get("at") or 0, reverse=True)
    return items[:limit]

ATTACH_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")

def save_upload(session_id, filename, data):
    """手机上传的附件存到会话工作区 attachments/，文件名去掉危险字符并加随机前缀。"""
    stem, ext = os.path.splitext(os.path.basename(filename or "file"))
    stem = ATTACH_NAME_RE.sub("_", stem).strip("._")[-60:] or "file"
    ext = ATTACH_NAME_RE.sub("", ext.lstrip("."))[:10].lower()
    base = stem + ("." + ext if ext else "")
    name = f"up_{uuid.uuid4().hex[:8]}_{base}"
    target, err = safe_path_resolve(session_id, os.path.join("attachments", name))
    if err:
        raise ValueError(err)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "wb") as f:
        f.write(data)
    return {"file_path": f"attachments/{name}", "filename": name, "bytes": len(data),
            "attachment_url": f"/v1/sessions/{session_id}/attachments/{name}"}

def library_media(bot_id, message_id, part):
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT m.content FROM messages m JOIN sessions s ON s.session_id = m.session_id WHERE m.id = ? AND s.persona_id = ?",
                           (message_id, bot_id)).fetchone()
    finally:
        conn.close()
    if not row:
        return None
    try:
        p = json.loads(row[0])[part]
        return p["image_url"]["url"] if isinstance(p.get("image_url"), dict) else p.get("image_url")
    except (ValueError, IndexError, KeyError, TypeError, AttributeError):
        return None

def _session_title(session_id):
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT title FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
        return (row[0] if row else None) or "云端会话"
    finally:
        conn.close()

def on_approval_required(task_id, session_id, approval):
    """审批挂起时推送提醒（Telegram 发起的任务另发带按钮的审批消息），异常不影响任务。"""
    try:
        telegram_notify_approval(task_id, approval)
    except Exception as e:
        print(f"telegram approval notify failed: {type(e).__name__}")
    cfg = current_notify_config()
    if not cfg or _bot_muted(session_id):
        return None
    args = json.dumps(approval.get("arguments"), ensure_ascii=False)
    body = f"{approval.get('reason', '')}\n工具：{approval.get('tool')}  {args[:300]}\n会话：{_session_title(session_id)}"
    cloud_notify.notify_async(cfg, "approval_required", "云电脑等待你的审批", body)

def on_task_finished(task_id, session_id, final_status):
    """对话任务结束时推送（例行任务由 on_routine_finished 推送；用户主动取消不推送）。"""
    if final_status not in ("completed", "failed", "limit_reached"):
        return None
    conn = get_db_connection()
    try:
        if conn.execute("SELECT 1 FROM routine_runs WHERE task_id = ?", (task_id,)).fetchone():
            return None
        row = conn.execute("SELECT content FROM messages WHERE session_id = ? AND role = 'assistant' AND content IS NOT NULL ORDER BY id DESC LIMIT 1", (session_id,)).fetchone()
    finally:
        conn.close()
    cfg = current_notify_config()
    if not cfg or _bot_muted(session_id):
        return None
    label = {"completed": "已完成", "failed": "失败", "limit_reached": "达到轮数上限"}[final_status]
    body = ((row[0] if row else "") or "").strip()[:600] or "（无文字回复）"
    cloud_notify.notify_async(cfg, "task_completed", f"云电脑任务{label}：{_session_title(session_id)}"[:120], body)

def request_approval(task_id, session_id, tool_call_id, tool_name, args, rule, timeout_seconds):
    """挂起任务直到用户批准、拒绝、超时或取消。返回 approved / denied / expired / cancelled。"""
    approval_id = "appr_" + uuid.uuid4().hex[:12]
    now = time.time()
    expires_at = now + timeout_seconds
    waiter = {"event": threading.Event(), "decision": None, "note": None, "task_id": task_id}
    with pending_approvals_lock:
        pending_approvals[approval_id] = waiter
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("INSERT INTO approvals (approval_id, task_id, tool_call_id, tool, arguments, rule_id, category, reason, status, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)",
                  (approval_id, task_id, tool_call_id, tool_name, json.dumps(args, ensure_ascii=False), rule["id"], rule["category"], rule["reason"], now, expires_at))
        c.execute("UPDATE tasks SET status = 'waiting_user' WHERE task_id = ? AND status = 'running'", (task_id,))
        conn.commit()
    finally:
        conn.close()
    approval = {"approval_id": approval_id, "tool_call_id": tool_call_id, "tool": tool_name, "arguments": args,
                "rule_id": rule["id"], "category": rule["category"], "reason": rule["reason"], "expires_at": expires_at}
    log_event(task_id, "approval_required", approval)
    try:
        on_approval_required(task_id, session_id, approval)
    except Exception:
        pass

    decision = None
    while decision is None:
        if waiter["event"].wait(0.25):
            decision = waiter["decision"]
        elif is_task_cancelled(task_id):
            decision = "cancelled"
        elif time.time() >= expires_at:
            decision = "expired"
    with pending_approvals_lock:
        pending_approvals.pop(approval_id, None)
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("UPDATE approvals SET status = ?, note = ?, decided_at = ? WHERE approval_id = ? AND status = 'pending'",
                  (decision, waiter.get("note"), time.time(), approval_id))
        if decision != "cancelled":
            c.execute("UPDATE tasks SET status = 'running' WHERE task_id = ? AND status = 'waiting_user'", (task_id,))
        conn.commit()
    finally:
        conn.close()
    log_event(task_id, "approval_resolved", {"approval_id": approval_id, "tool_call_id": tool_call_id, "decision": decision})
    return decision

def resolve_approval(task_id, approval_id, decision, note=None):
    """返回 (http_status, body)。"""
    with pending_approvals_lock:
        waiter = pending_approvals.get(approval_id)
        if waiter and waiter["task_id"] == task_id and waiter["decision"] is None:
            waiter["decision"] = decision
            waiter["note"] = note
            waiter["event"].set()
            return 200, {"approval_id": approval_id, "task_id": task_id, "status": decision}
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT status FROM approvals WHERE approval_id = ? AND task_id = ?", (approval_id, task_id))
        row = c.fetchone()
    finally:
        conn.close()
    if not row:
        return 404, {"error": "Approval not found"}
    return 409, {"error": "Approval already resolved", "approval_id": approval_id, "status": row[0]}

def list_approvals(task_id):
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT approval_id, tool_call_id, tool, arguments, rule_id, category, reason, status, note, created_at, expires_at, decided_at FROM approvals WHERE task_id = ? ORDER BY created_at ASC", (task_id,))
        rows = c.fetchall()
    finally:
        conn.close()
    out = []
    for r in rows:
        try: args = json.loads(r[3])
        except Exception: args = {}
        out.append({"approval_id": r[0], "tool_call_id": r[1], "tool": r[2], "arguments": args, "rule_id": r[4],
                    "category": r[5], "reason": r[6], "status": r[7], "note": r[8], "created_at": r[9],
                    "expires_at": r[10], "decided_at": r[11]})
    return out

def log_event(task_id, etype, payload):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute(
        "INSERT INTO task_events (task_id, event_type, payload, timestamp) VALUES (?, ?, ?, ?)",
        (task_id, etype, json.dumps(payload, ensure_ascii=False), time.time())
    )
    conn.commit()
    conn.close()

def tool_shell_execute(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Task was cancelled"}
    cmd = args.get("command", "")
    timeout = int(args.get("timeout", 60))
    if not cmd:
        return {"error": "Missing command"}
    ws = get_session_workspace(session_id)
    bot_id = session_persona_id(session_id)
    limits = iso.bot_settings(resource_settings(), bot_id)
    env = task_env(session_id)
    if args.get("background"):
        lane = task_lane(session_id)
        cap = limits.get("bg_jobs_max") or 0
        if cap and BG_JOBS.running_count(lane) >= cap:
            return {"error": f"后台命令已达上限 {cap} 个，请等待或用 background_jobs 停止一个"}
        job = BG_JOBS.start(lane, session_id, cmd, ws, env, limits, os.path.join(ws, ".bg"), on_background_done)
        return {"status": "started", "job_id": job["job_id"], "log": os.path.relpath(job["log"], ws),
                "note": "命令在后台运行，完成后会写回对话并推送；可用 background_jobs 查看进度。"}
    argv, use_shell, preexec = iso.wrap_command(cmd, limits)
    system_op = resource_settings()["system_lock"] and iso.is_system_op(cmd)
    if system_op and not iso.SYSTEM_LOCK.acquire(blocking=False):
        log_event(task_id, "status", {"message": "等待其他 Bot 的系统级安装完成…"})
        if not iso.SYSTEM_LOCK.acquire(timeout=max(timeout, 600)):
            return {"error": "等待系统级操作锁超时（其他 Bot 正在安装软件或修改系统配置）"}
    try:
        with tempfile.TemporaryFile() as out_f, tempfile.TemporaryFile() as err_f:
            proc = subprocess.Popen(argv, shell=use_shell, stdout=out_f, stderr=err_f, cwd=ws, env=env,
                                    start_new_session=True, preexec_fn=preexec)
            with active_tasks_lock:
                if task_id in active_tasks:
                    active_tasks[task_id]["process"] = proc
                    active_tasks[task_id]["pid"] = proc.pid
            start_t = time.time()
            while proc.poll() is None:
                if is_task_cancelled(task_id):
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        proc.kill()
                    proc.wait()
                    return {"error": "Command terminated due to cancellation"}
                if time.time() - start_t > timeout:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        proc.kill()
                    proc.wait()
                    return {"error": f"Timeout after {timeout}s"}
                time.sleep(0.1)
            proc.wait()
            out_f.seek(0)
            err_f.seek(0)
            return {
                "exit_code": proc.returncode,
                "stdout": out_f.read(32768).decode("utf-8", "replace"),
                "stderr": err_f.read(32768).decode("utf-8", "replace")
            }
    except Exception as e:
        return {"error": str(e)}
    finally:
        if system_op:
            iso.SYSTEM_LOCK.release()

def tool_file_read(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    target, err = safe_path_resolve(session_id, args.get("path", ""))
    if err:
        return {"error": err}
    if not os.path.exists(target) or not os.path.isfile(target):
        return {"error": "Not found"}
    try:
        if os.path.getsize(target) > 2 * 1024 * 1024:
            return {"error": "Too large (>2MB)"}
        with open(target, "r", encoding="utf-8") as f:
            return {"content": f.read()}
    except Exception as e:
        return {"error": str(e)}

def tool_file_write(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    target, err = safe_path_resolve(session_id, args.get("path", ""))
    if err:
        return {"error": err}
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "w", encoding="utf-8") as f:
            f.write(args.get("content", ""))
        return {"status": "success", "path": args.get("path")}
    except Exception as e:
        return {"error": str(e)}

def tool_file_edit(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    target, err = safe_path_resolve(session_id, args.get("path", ""))
    if err:
        return {"error": err}
    if not os.path.exists(target):
        return {"error": "Not found"}
    try:
        with open(target, "r", encoding="utf-8") as f:
            content = f.read()
        old_s, new_s = args.get("old_string", ""), args.get("new_string", "")
        if old_s not in content:
            return {"error": "old_string not found"}
        with open(target, "w", encoding="utf-8") as f:
            f.write(content.replace(old_s, new_s, 1))
        return {"status": "success", "path": args.get("path")}
    except Exception as e:
        return {"error": str(e)}

def tool_browser_action(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    ws = get_session_workspace(session_id)
    key, owner, display = browser_route(session_id)
    return cloud_browser.execute_browser_action(key, ws, args, owner=owner, display=display)

# ---------- 多 Bot 隔离：资源设置、排队、屏幕、端口、后台命令 ----------
_resource_cache = {"value": None}
_resource_lock = threading.Lock()

def _settings_get(name):
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT value FROM app_settings WHERE name = ?", (name,)).fetchone()
        return json.loads(row[0]) if row else None
    except (ValueError, sqlite3.Error):
        return None
    finally:
        conn.close()

def _settings_put(name, value):
    conn = get_db_connection()
    try:
        conn.execute("INSERT INTO app_settings (name, value) VALUES (?, ?) ON CONFLICT(name) DO UPDATE SET value = excluded.value",
                     (name, json.dumps(value, ensure_ascii=False)))
        conn.commit()
    finally:
        conn.close()

def resource_settings():
    with _resource_lock:
        if _resource_cache["value"] is None:
            _resource_cache["value"] = iso.merged_with_defaults(_settings_get("resources"))
        return _resource_cache["value"]

def update_resource_settings(patch):
    with _resource_lock:
        current = _resource_cache["value"] or iso.merged_with_defaults(_settings_get("resources"))
        new = iso.validate(patch, current)
        _settings_put("resources", new)
        _resource_cache["value"] = new
    GATE.poke()
    return new

_index_lock = threading.Lock()

def slot_index(key):
    """Bot / 屏幕键的稳定编号（>=1），用于屏幕号 :10+N 与端口段。"""
    with _index_lock:
        idx = _settings_get("slot_index") or {}
        if key not in idx:
            used = set(idx.values())
            idx[key] = next(i for i in range(1, 10000) if i not in used)
            _settings_put("slot_index", idx)
        return idx[key]

def task_lane(session_id):
    pid = session_persona_id(session_id)
    return ("bot:" + pid) if pid else ("session:" + session_id)

def display_key(session_id):
    pid = session_persona_id(session_id)
    if not pid:
        return None
    slot = ACTIVE_SLOTS.get(session_id, 0)
    return pid if not slot else f"{pid}:{slot}"

def browser_route(session_id):
    """(浏览器资料键, 标签页归属, DISPLAY)。共享模式：所有 Bot 共用 shared 资料（登录状态共享），
    浏览器开在主屏 :99，每个 Bot 记住自己的标签页；独立模式：Bot 自己的资料和独立屏幕。"""
    pid = session_persona_id(session_id)
    owner = pid or session_id
    if pid and iso.bot_settings(resource_settings(), pid)["browser_profile"] == "per_bot":
        info = DISPLAYS.ensure(display_key(session_id))
        if info:
            DISPLAYS.touch(display_key(session_id))
            return "bot-" + display_key(session_id).replace(":", "-"), owner, info["display"]
        return "bot-" + pid, owner, None
    return "shared", owner, None

def task_env(session_id):
    env = os.environ.copy()
    s = resource_settings()
    env.update(iso.mirror_env(s, os.path.join(os.path.dirname(GLOBAL_WORKSPACE), "cache")))
    pid = session_persona_id(session_id)
    ports = iso.bot_port_range(s, slot_index("bot:" + pid) if pid else 0)
    env["OPENMINIS_SHARED"] = SHARED_WORKSPACE
    env["OPENMINIS_PORTS"] = f"{ports[0]}-{ports[-1]}" if ports else ""
    if ports:
        env["PORT"] = str(ports[0])
    _k, _o, display = browser_route(session_id) if pid else (None, None, None)
    if display:
        env["DISPLAY"] = display
    os.makedirs(SHARED_WORKSPACE, exist_ok=True)
    return env

def isolation_note(session_id):
    s = resource_settings()
    pid = session_persona_id(session_id)
    ports = iso.bot_port_range(s, slot_index("bot:" + pid) if pid else 0)
    return ("\n[工作区] 你的 Shell 当前目录是你自己的工作区；和其他 Bot 交换文件用环境变量 $OPENMINIS_SHARED 目录"
            "（文件工具里写作 @shared/文件名）。"
            + (f"开发服务器请只用端口 {ports[0]}–{ports[-1]}（$PORT 为第一个），不要占用 18765/18766。" if ports else "")
            + "耗时很久的命令（安装、编译、下载）用 shell_execute 的 background=true 在后台跑，完成后会通知你，别阻塞对话。")

def on_background_done(job, log_tail):
    sid = job["session_id"]
    text = (f"[后台命令完成] {job['job_id']} 退出码 {job['exit_code']}\n命令：{job['command'][:200]}\n"
            f"最后输出：\n{log_tail[-1500:]}")
    conn = get_db_connection()
    try:
        busy = conn.execute("SELECT 1 FROM tasks WHERE session_id = ? AND status IN ('running', 'waiting_user')", (sid,)).fetchone()
        if not busy:
            conn.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'assistant', ?, ?)",
                         (sid, text, time.time()))
            conn.commit()
    finally:
        conn.close()
    cfg = current_notify_config()
    if cfg and not _bot_muted(sid):
        cloud_notify.notify_async(cfg, "task_completed", f"后台命令完成：{_session_title(sid)}"[:120], text[:600])

def tool_background_jobs(task_id, session_id, args):
    action = (args or {}).get("action", "list")
    lane = task_lane(session_id)
    if action == "list":
        return {"jobs": [{k: v for k, v in j.items() if k not in ("pid", "lane")} for j in BG_JOBS.list(lane)]}
    job = BG_JOBS.get(str(args.get("job_id", "")))
    if not job or job["lane"] != lane:
        return {"error": "没有这个后台命令"}
    if action == "log":
        return {"job_id": job["job_id"], "status": job["status"], "exit_code": job["exit_code"], "log_tail": iso.tail(job["log"])}
    if action == "stop":
        return {"stopped": BG_JOBS.stop(job["job_id"])}
    return {"job_id": job["job_id"], "status": job["status"], "exit_code": job["exit_code"]}

def resource_usage():
    st = GATE.status()
    return {"running_tasks": len(st["running"]), "queued_tasks": len(st["queued"]),
            "running_bots": len({r["lane"] for r in st["running"]}), "displays_open": len(DISPLAYS.list()),
            "background_jobs": sum(1 for j in BG_JOBS.list() if j["status"] == "running"),
            "displays": DISPLAYS.list(), "queue": st["queued"]}

def _close_browser_for_display(key):
    try:
        cloud_browser.execute_browser_action("bot-" + key.replace(":", "-"), SHARED_WORKSPACE, {"action": "__close__"})
    except Exception:
        pass

GATE = iso.TaskGate(resource_settings)
DISPLAYS = cloud_displays.DisplayManager(resource_settings, slot_index, on_stop=_close_browser_for_display)
BG_JOBS = iso.BackgroundJobs()

def tool_request_user_takeover(task_id, session_id, args):
    """需要用户亲自操作（登录、验证码、扫码、付款确认）时请求接管：记事件让手机显示「打开电脑」卡片，并推送提醒。"""
    reason = str((args or {}).get("reason") or "").strip()[:300] or "需要你在云电脑上完成一步操作"
    log_event(task_id, "takeover_request", {"reason": reason})
    cfg = current_notify_config()
    if cfg and not _bot_muted(session_id):
        cloud_notify.notify_async(cfg, "approval_required", "Bot 需要你帮忙"[:120],
                                  f"{reason}\n打开 App → 电脑 接管，完成后点「我完成了」。\n会话：{_session_title(session_id)}")
    return {"status": "requested", "reason": reason,
            "note": "已请求用户在手机「电脑」页接管。现在结束本轮，用一两句话告诉用户需要做什么；"
                    "用户完成后会发来“我完成了”，届时先截图确认结果再继续。不要索要或记录密码。"}

def tool_desktop_action(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    ws = get_session_workspace(session_id)
    _key, _owner, display = browser_route(session_id)
    return cloud_desktop.execute_desktop_action(session_id, ws, args, display_override=display)

def tool_memory_write(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    conn = get_db_connection()
    try:
        entry, created = cloud_memory.write(conn, args.get("content"), args.get("category"), source="cloud", session_id=session_id,
                                            persona=session_persona_id(session_id) or "")
    except ValueError as e:
        return {"error": str(e)}
    finally:
        conn.close()
    return {"saved": created, "duplicate": not created, "id": entry["id"], "category": entry["category"], "entry_time": entry["entry_time"]}

def tool_memory_search(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    conn = get_db_connection()
    try:
        results = cloud_memory.search(conn, args.get("query", ""), args.get("category") or None, args.get("limit", 10),
                                      persona=session_persona_id(session_id) or "")
    except (ValueError, TypeError) as e:
        return {"error": str(e)}
    finally:
        conn.close()
    total = 0
    out = []
    for r in results:
        text = r["content"] if len(r["content"]) <= 4000 else r["content"][:4000] + "…"
        total += len(text)
        out.append({"id": r["id"], "category": r["category"], "entry_time": r["entry_time"], "source": r["source"], "content": text})
        if total > 30000:
            break
    return {"count": len(out), "results": out}

SERVER_TOOL_NOTES = (
    "\n\n[云端记忆] memory_search 按关键词检索用户的长期记忆（手机同步的 memory/ 日志与 GLOBAL.md，以及云端写入的条目），"
    "开始新话题或需要用户偏好、人物、项目背景时先检索；memory_write 保存值得长期记住的新事实，category 取 "
    "profile（用户本人）/ rules（偏好与约定）/ people（人物）/ workstreams（项目进展）/ note（其他）。不要写入密码、密钥等凭据。"
    "\n[页面库] 报告、表格、看板、可交互的小工具等适合长期查看的成果，用 page_write 保存为完整 HTML 页面（可内联 CSS/JS，不能依赖外部登录态），"
    "用户可在手机“云端页面库”中打开；更新同一页面时传回 page_id。"
    "\n[子代理] 可拆分、互不依赖的子任务可用 subagent_task 交给独立会话的子代理执行，它返回最终结论；子代理不能再派生子代理。"
    "\n[生成图片] 用户要图片时调用 image_generate，图片保存在工作区 attachments/。"
    "\n[发消息] send_message 可经 Telegram 或推送给用户发消息；每次都会先作为草稿请用户确认，被拒绝时不要重试同一内容。"
)

PLUGINS = cloud_plugins.Registry(lambda: get_db_connection(), os.path.join(BASE_DIR, "plugin-files"), cloud_skills)
import atexit
atexit.register(PLUGINS.close_all)

def plugin_tools_for_session(session_id, depth):
    """返回 (工具定义, 名称映射, 系统提示补充)。插件出错不影响任务本身。"""
    try:
        defs, mapping, unavailable = PLUGINS.tool_definitions(session_bot(session_id))
    except Exception as e:
        print(f"plugin tools failed: {e}")
        return [], {}, ""
    note = ""
    if mapping:
        note += "\n[插件] 名为 mcp__<插件>__<工具> 的函数来自用户安装的 MCP 插件，结果以插件真实返回为准。"
    if unavailable:
        note += "\n[插件不可用] " + "；".join(
            f"{p['name']}（{'需要授权：请用户在手机“插件”页填写密钥' if 'needs_auth' in err else err[:80]}）" for p, err in unavailable[:10])
    return defs, mapping, note

PERSONA_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,31}$")

def session_persona_id(session_id):
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT persona_id FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
        return row[0] if row and row[0] else None
    finally:
        conn.close()

def get_persona(persona_id):
    if not persona_id:
        return None
    conn = get_db_connection()
    try:
        return cloud_bots.get(conn, persona_id)
    finally:
        conn.close()

def credential_exists(name):
    return bool(CREDENTIAL_NAME_RE.match(name)) and any(c["name"] == name for c in list_credentials())

def bot_detail(bot):
    conn = get_db_connection()
    try:
        pid = bot["persona_id"]
        out = dict(bot)
        out["session_count"] = conn.execute("SELECT COUNT(*) FROM sessions WHERE persona_id = ?", (pid,)).fetchone()[0]
        out["routine_count"] = conn.execute("SELECT COUNT(*) FROM routines WHERE persona_id = ?", (pid,)).fetchone()[0]
        out["memory_count"] = conn.execute("SELECT COUNT(*) FROM memory_entries WHERE persona = ?", (pid,)).fetchone()[0]
        out["telegram"] = conn.execute("SELECT 1 FROM secure_settings WHERE name = ?", (telegram_setting_name(pid),)).fetchone() is not None
        # 首页 Bot 列表：最近会话、最后一条可见消息、运行中 / 待审批任务数
        latest = conn.execute("SELECT s.session_id, s.title FROM sessions s LEFT JOIN messages m ON m.session_id = s.session_id "
                              "WHERE s.persona_id = ? GROUP BY s.session_id ORDER BY MAX(COALESCE(m.timestamp, s.created_at)) DESC LIMIT 1", (pid,)).fetchone()
        out["latest_session_id"] = latest[0] if latest else None
        out["latest_session_title"] = latest[1] if latest else None
        last = conn.execute("SELECT m.role, m.content, m.timestamp, m.session_id FROM messages m JOIN sessions s ON s.session_id = m.session_id "
                            "WHERE s.persona_id = ? AND m.role IN ('user', 'assistant') AND m.content IS NOT NULL AND m.content != '' "
                            "ORDER BY m.timestamp DESC, m.id DESC LIMIT 1", (pid,)).fetchone()
        out["last_message"] = {"role": last[0], "preview": " ".join(str(last[1]).split())[:120], "at": last[2], "session_id": last[3]} if last else None
        counts = dict(conn.execute("SELECT t.status, COUNT(*) FROM tasks t JOIN sessions s ON s.session_id = t.session_id "
                                   "WHERE s.persona_id = ? AND t.status IN ('running', 'queued', 'waiting_user') GROUP BY t.status", (pid,)).fetchall())
        out["notify"] = pid not in muted_bots()
        out["queued_tasks"] = sum(1 for q in GATE.status()["queued"] if q["lane"] == "bot:" + pid)
        out["resources"] = iso.bot_settings(resource_settings(), pid)
        out["resource_overrides"] = resource_settings()["bot_overrides"].get(pid, {})
        out["routines_enabled"] = conn.execute("SELECT COUNT(*) FROM routines WHERE persona_id = ? AND enabled = 1", (pid,)).fetchone()[0]
        out["running_tasks"] = counts.get("running", 0) + counts.get("queued", 0)
        out["waiting_approvals"] = counts.get("waiting_user", 0)
        return out
    finally:
        conn.close()

def import_bot_bundle(req):
    bundle = req.get("bundle")
    if not isinstance(bundle, dict) or bundle.get("format") != cloud_bots.EXPORT_FORMAT or not isinstance(bundle.get("bot"), dict):
        raise cloud_bots.BotError("bundle must be an openminis-bot/1 export")
    base = req.get("bot_id") or bundle.get("bot_id") or "bot"
    if not isinstance(base, str) or not cloud_bots.BOT_ID_RE.match(base):
        raise cloud_bots.BotError("bot_id must match ^[a-z0-9][a-z0-9_-]{0,31}$")
    conn = get_db_connection()
    try:
        bot_id, n = base, 2
        while cloud_bots.get(conn, bot_id):
            bot_id = f"{base[:28]}-{n}"
            n += 1
        body = {k: v for k, v in bundle["bot"].items() if k in ("name", "emoji", "description", "instructions", "skills", "plugins")}
        if req.get("credential") and (req.get("model") or bundle["bot"].get("model")):
            body["credential"] = req["credential"]
            body["model"] = req.get("model") or bundle["bot"].get("model")
        bot, _ = cloud_bots.upsert(conn, bot_id, body, credential_exists)
        imported_memory = 0
        for m in (bundle.get("memory") or [])[:2000]:
            if isinstance(m, dict) and isinstance(m.get("content"), str) and m["content"].strip():
                try:
                    _, created = cloud_memory.write(conn, m["content"], m.get("category"), source="import", entry_time=m.get("entry_time"), commit=False, persona=bot_id)
                    imported_memory += 1 if created else 0
                except ValueError:
                    pass
        conn.commit()
    finally:
        conn.close()
    created_routines, skipped = [], []
    cred = req.get("credential")
    model = req.get("model") or bundle["bot"].get("model")
    for r in (bundle.get("routines") or [])[:50]:
        if not isinstance(r, dict):
            continue
        if not cred or not model:
            skipped.append(r.get("name"))
            continue
        try:
            fields = validate_routine_fields(dict(r, credential=cred, model=model, persona_id=bot_id, enabled=False))
            created_routines.append(create_routine(fields)["routine_id"])
        except ValueError:
            skipped.append(r.get("name"))
    return {"bot": bot, "memory_imported": imported_memory, "routines_created": created_routines,
            "routines_skipped": skipped, "note": "导入的例行任务默认停用，确认后再启用" if created_routines else None}

def primary_bot_id():
    conn = get_db_connection()
    try:
        p = cloud_bots.primary(conn)
    finally:
        conn.close()
    return p["persona_id"] if p else None

def list_personas():
    conn = get_db_connection()
    try:
        rows = conn.execute("SELECT persona_id FROM personas ORDER BY created_at ASC").fetchall()
    finally:
        conn.close()
    return [get_persona(r[0]) for r in rows]

def validate_persona_ref(value):
    """None / '' 表示默认人格；其余必须是已存在的 persona_id。"""
    if value in (None, ""):
        return None
    if not isinstance(value, str) or not PERSONA_ID_RE.match(value) or not get_persona(value):
        raise ValueError("persona_id does not exist")
    return value

def persona_prompt(session_id):
    p = get_persona(session_persona_id(session_id))
    if not p:
        return ""
    return cloud_bots.prompt(p, [b for b in list_personas() if b["persona_id"] != p["persona_id"]])

def mention_note(session_id, content):
    """用户消息里 @ 了其他 Bot 时，提示模型用 subagent_task(persona=...) 转交。"""
    if not isinstance(content, str) or "@" not in content:
        return ""
    own = session_persona_id(session_id)
    bots = [b for b in list_personas() if b["persona_id"] != own]
    ids = cloud_bots.mentions(content, bots)
    if not ids:
        return ""
    return ("\n[@提及] 用户在消息中 @ 了：" + "、".join(ids) + "。请用 delegate_task(bot_id=…) 把相应部分交给这些 Bot"
            "（它们在自己的工作区用自己的模型完成），再把它们的结果整合给用户；只想快速问一句可用 subagent_task 并传 persona。")

def session_bot(session_id):
    return get_persona(session_persona_id(session_id))

def server_tool_notes(session_id):
    """追加到 system 消息的服务端工具说明（客户端 instructions 不了解服务端新增工具）与技能索引。"""
    conn = get_db_connection()
    bot = session_bot(session_id)
    try:
        skills_index = cloud_skills.index_text(conn, lambda n: cloud_bots.skill_allowed(bot, n))
    except Exception as e:
        print(f"skills index failed: {e}")
        skills_index = ""
    finally:
        conn.close()
    try:
        own = session_persona_id(session_id)
        others = [p for p in list_personas() if p["persona_id"] != own]
    except Exception:
        others = []
    personas_note = ""
    if others:
        personas_note += ("\n[Bot 协作] 需要别的 Bot 动手做事时用 delegate_task（在对方工作区执行，结果交回给你），只是通知用 send_to_bot；"
                          "收到以「【来自 …】」开头的消息说明是别的 Bot 交给你的，完成后最后一条回复写清结果。list_bots 查看所有 Bot。")
        personas_note += "\n[其他人格] 需要其他人格的专长或它们的私有记忆时，用 subagent_task 并传 persona 询问：" + "；".join(
            f"{p['persona_id']}（{p['name']}）" for p in others[:20])
    return SERVER_TOOL_NOTES + personas_note + isolation_note(session_id) + skills_index

def tool_skill_load(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    name = args.get("name")
    conn = get_db_connection()
    try:
        bot = session_bot(session_id)
        skill = cloud_skills.load(conn, name) if isinstance(name, str) and cloud_bots.skill_allowed(bot, name) else None
        if not skill:
            names = [s["name"] for s in cloud_skills.list_index(conn) if cloud_bots.skill_allowed(bot, s["name"])]
            close = [n for n in names if isinstance(name, str) and name.lower() in n.lower()][:10]
            return {"error": f"技能不存在：{name}", "similar": close}
    finally:
        conn.close()
    return {"name": skill["name"], "description": skill["description"], "content": skill["content"]}

def tool_page_write(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    conn = get_db_connection()
    try:
        page = cloud_pages.write(conn, args.get("title"), args.get("html"), page_id=args.get("page_id") or None,
                                 session_id=session_id, task_id=task_id)
    except ValueError as e:
        return {"error": str(e)}
    except KeyError:
        return {"error": f"page_id 不存在：{args.get('page_id')}"}
    finally:
        conn.close()
    return {"status": "ok", "page_id": page["page_id"], "title": page["title"], "version": page["version"], "size": page["size"]}

SUBAGENT_MAX_PER_TASK = int(os.environ.get("OPENMINIS_SUBAGENT_MAX", "8"))
SUBAGENT_INSTRUCTIONS = (
    "你是 OpenMinis 云端子代理，在用户的 Linux 云电脑上独立完成父代理交给你的一个子任务。"
    "只做这个子任务，用工具核实结果，最后用简洁中文给出结论与关键依据（会原样返回给父代理）。不能再派生子代理。"
)

def tool_subagent_task(task_id, session_id, args, model, provider_config, depth):
    if depth >= 1:
        return {"error": "子代理不能再派生子代理"}
    prompt = args.get("task")
    if not isinstance(prompt, str) or not prompt.strip():
        return {"error": "task must be a non-empty string"}
    title = (args.get("title") or prompt.strip().splitlines()[0])[:60]
    target_persona = args.get("persona")
    if target_persona in (None, ""):
        target_persona = session_persona_id(session_id)
        title_prefix = "子代理："
    else:
        target = get_persona(target_persona) if isinstance(target_persona, str) else None
        if not target:
            return {"error": f"人格不存在：{target_persona}", "personas": [p["persona_id"] for p in list_personas()]}
        title_prefix = "询问" + target["name"] + "："
    with active_tasks_lock:
        parent_entry = active_tasks.get(task_id)
        if parent_entry is not None:
            used = parent_entry.get("subagents", 0)
            if used >= SUBAGENT_MAX_PER_TASK:
                return {"error": f"本任务子代理数量已达上限 {SUBAGENT_MAX_PER_TASK}"}
            parent_entry["subagents"] = used + 1
    sid = "sess_" + uuid.uuid4().hex[:12]
    tid = "task_" + uuid.uuid4().hex[:12]
    now = time.time()
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("INSERT INTO sessions (session_id, local_session_id, title, instructions, created_at, persona_id) VALUES (?, NULL, ?, ?, ?, ?)",
                  (sid, title_prefix + title, SUBAGENT_INSTRUCTIONS, now, target_persona))
        c.execute("INSERT INTO tasks (task_id, session_id, client_nonce, status, model, created_at) VALUES (?, ?, NULL, 'running', ?, ?)",
                  (tid, sid, model, now))
        c.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'user', ?, ?)", (sid, prompt, now))
        conn.commit()
    finally:
        conn.close()
    with active_tasks_lock:
        active_tasks[tid] = {"process": None, "cancelled": False, "pid": None, "parent": task_id}
    log_event(task_id, "subagent_started", {"task_id": tid, "session_id": sid, "title": title})
    run_agent_task(tid, sid, prompt, model, provider_config, SUBAGENT_INSTRUCTIONS, depth=depth + 1)
    conn = get_db_connection()
    try:
        c = conn.cursor()
        status = (c.execute("SELECT status FROM tasks WHERE task_id = ?", (tid,)).fetchone() or ["failed"])[0]
        last = c.execute("SELECT content FROM messages WHERE session_id = ? AND role = 'assistant' AND content IS NOT NULL ORDER BY id DESC LIMIT 1", (sid,)).fetchone()
    finally:
        conn.close()
    result = (last[0] if last else "") or ""
    log_event(task_id, "subagent_finished", {"task_id": tid, "session_id": sid, "status": status})
    out = {"status": status, "subagent_task_id": tid, "subagent_session_id": sid, "persona": target_persona, "result": result[:20000]}
    if status != "completed":
        out["error"] = f"子代理结束状态：{status}"
    return out

# ---------------- Bot 之间的消息与委托 ----------------
TASK_HOP = {}            # task_id -> 委托层数（用户直接发起的是 0）
TASK_PRIORITY = {}       # task_id -> "high" 时排到普通任务前面
DELEG_LIMITER = deleg.PairLimiter()
DELEG_THREADS = {}       # delegation_id -> worker 线程
DELEG_WAIT_DEFAULT = 600
DELEG_WAITING = set()    # 请求方正在同步等待结果的委托：worker 结束时不另行回报
DELEG_LOCK = threading.Lock()

def _bot_label(bot):
    return (bot or {}).get("name") or "主助手"

def tool_list_bots(task_id, session_id, args):
    own = session_persona_id(session_id)
    conn = get_db_connection()
    try:
        busy = {r[0] for r in conn.execute(
            "SELECT s.persona_id FROM tasks t JOIN sessions s ON s.session_id = t.session_id WHERE t.status IN ('running', 'waiting_user')")}
    finally:
        conn.close()
    bots = []
    for b in list_personas():
        if b["persona_id"] == own:
            continue
        bots.append({"bot_id": b["persona_id"], "name": b["name"], "description": (b.get("description") or "")[:200],
                     "model": b.get("model") or "", "busy": b["persona_id"] in busy})
    return {"bots": bots, "you": own or ""}

def _delegation_row(did):
    conn = get_db_connection()
    try:
        conn.row_factory = sqlite3.Row
        r = conn.execute("SELECT * FROM bot_delegations WHERE delegation_id = ?", (did,)).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()

def list_delegations(session_id=None, limit=50):
    conn = get_db_connection()
    try:
        conn.row_factory = sqlite3.Row
        if session_id:
            rows = conn.execute("SELECT * FROM bot_delegations WHERE from_session = ? OR to_session = ? ORDER BY created_at DESC LIMIT ?",
                                (session_id, session_id, limit)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM bot_delegations ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def _post_when_idle(session_id, text, timeout=1800):
    """等会话空闲后把一条 assistant 消息写进去（不在别的任务的工具调用中间插消息）。"""
    deadline = time.time() + timeout
    while True:
        conn = get_db_connection()
        try:
            busy = conn.execute("SELECT 1 FROM tasks WHERE session_id = ? AND status IN ('running', 'waiting_user')", (session_id,)).fetchone()
            if not busy or time.time() > deadline:
                conn.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'assistant', ?, ?)",
                             (session_id, text, time.time()))
                conn.commit()
                return True
        finally:
            conn.close()
        time.sleep(1.0)

def start_delegation(task_id, session_id, kind, target_id, body, priority="normal", report_back=True,
                     model=None, provider_config=None, waiting=False):
    """创建并启动一次 Bot 间消息 / 委托；返回 (delegation_id, worker 线程) 或抛 deleg.LimitError / ValueError。"""
    own = session_persona_id(session_id)
    if not isinstance(target_id, str) or not target_id:
        raise ValueError("bot_id 必须是字符串")
    if target_id == own:
        raise ValueError("不能委托给自己；需要分身处理请用 subagent_task")
    target = get_persona(target_id)
    if not target:
        raise ValueError(f"没有这个 Bot：{target_id}")
    if not isinstance(body, str) or not body.strip():
        raise ValueError("内容不能为空")
    if priority not in ("normal", "high"):
        raise ValueError("priority 只能是 normal 或 high")
    rs = resource_settings()
    hop = TASK_HOP.get(task_id, 0) + 1
    deleg.check_hop(hop, rs.get("delegation_max_hops", 3))
    DELEG_LIMITER.check_and_add(own or "", target_id, rs.get("delegation_pair_per_10min", 10))
    src = session_bot(session_id)
    did = "dlg_" + uuid.uuid4().hex[:12]
    content = deleg.incoming_text(_bot_label(src), kind, body[:20000], did, report_back)
    if target.get("model") and target.get("credential"):
        run_model = target["model"]
        provider, p_status, p_err = resolve_provider({"protocol": "chat", "credential": target["credential"]})
        if p_err:
            raise ValueError(f"{target['name']} 的模型凭据不可用：{p_err}")
    else:
        run_model, provider = model, provider_config
    if not provider:
        raise ValueError("没有可用的模型凭据")
    now = time.time()
    tid = "task_" + uuid.uuid4().hex[:12]
    conn = get_db_connection()
    try:
        c = conn.cursor()
        sid = None
        if kind == "message":
            # 普通消息进目标 Bot 最近的空闲会话，没有就新开
            r = c.execute("SELECT s.session_id FROM sessions s WHERE s.persona_id = ? AND NOT EXISTS (SELECT 1 FROM tasks t WHERE t.session_id = s.session_id "
                          "AND t.status IN ('running', 'waiting_user')) AND s.title NOT LIKE '例行任务：%' ORDER BY s.created_at DESC LIMIT 1", (target_id,)).fetchone()
            sid = r[0] if r else None
        if not sid:
            sid = "sess_" + uuid.uuid4().hex[:12]
            title = f"来自 {_bot_label(src)}：" + body.strip().splitlines()[0][:40]
            c.execute("INSERT INTO sessions (session_id, local_session_id, title, instructions, created_at, persona_id) VALUES (?, NULL, ?, '', ?, ?)",
                      (sid, title, now, target_id))
        c.execute("INSERT INTO tasks (task_id, session_id, client_nonce, status, model, created_at) VALUES (?, ?, NULL, 'running', ?, ?)",
                  (tid, sid, run_model, now))
        c.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'user', ?, ?)", (sid, content, now))
        root = (c.execute("SELECT root_id FROM bot_delegations WHERE to_task = ?", (task_id,)).fetchone() or [did])[0]
        c.execute("INSERT INTO bot_delegations (delegation_id, kind, from_bot, to_bot, from_session, from_task, to_session, to_task, content, priority, "
                  "report_back, hop, root_id, status, result, reported, created_at, finished_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, 'running', NULL, 0, ?, NULL)",
                  (did, kind, own or "", target_id, session_id, task_id, sid, tid, body[:20000], priority, 1 if report_back else 0, hop, root, now))
        conn.commit()
    finally:
        conn.close()
    with active_tasks_lock:
        active_tasks[tid] = {"process": None, "cancelled": False, "pid": None, "parent": task_id}
    TASK_HOP[tid] = hop
    if priority == "high":
        TASK_PRIORITY[tid] = "high"
    log_event(task_id, "delegation_started", {"delegation_id": did, "kind": kind, "to_bot": target_id, "to_name": target["name"],
                                              "session_id": sid, "task_id": tid, "message": f"已交给 {target['name']}"})
    log_event(tid, "delegated_from", {"delegation_id": did, "from_bot": own or "", "from_name": _bot_label(src)})

    def worker():
        try:
            run_agent_task(tid, sid, content, run_model, provider, "")
        finally:
            TASK_HOP.pop(tid, None)
            TASK_PRIORITY.pop(tid, None)
            conn2 = get_db_connection()
            try:
                status = (conn2.execute("SELECT status FROM tasks WHERE task_id = ?", (tid,)).fetchone() or ["failed"])[0]
                last = conn2.execute("SELECT content FROM messages WHERE session_id = ? AND role = 'assistant' AND content IS NOT NULL AND timestamp >= ? "
                                     "ORDER BY id DESC LIMIT 1", (sid, now)).fetchone()
                result = ((last[0] if last else "") or "")[:20000]
                conn2.execute("UPDATE bot_delegations SET status = ?, result = ?, finished_at = ? WHERE delegation_id = ?",
                              (status, result, time.time(), did))
                conn2.commit()
            finally:
                conn2.close()
            log_event(task_id, "delegation_finished", {"delegation_id": did, "to_name": target["name"], "status": status})
            DELEG_THREADS.pop(did, None)
            with DELEG_LOCK:
                deferred = did in DELEG_WAITING
            if report_back and kind == "task" and not deferred:
                _report_delegation(did)

    th = threading.Thread(target=worker, daemon=True, name="bot-delegation")
    DELEG_THREADS[did] = th
    if waiting:
        with DELEG_LOCK:
            DELEG_WAITING.add(did)
    th.start()
    return did, th

def _claim_report(did):
    """回报只做一次：谁先把 reported 从 0 改成 1 谁负责交付结果。"""
    conn = get_db_connection()
    try:
        cur = conn.execute("UPDATE bot_delegations SET reported = 1 WHERE delegation_id = ? AND reported = 0", (did,))
        conn.commit()
        return cur.rowcount == 1
    finally:
        conn.close()

def _report_delegation(did):
    """结果交回请求方：请求方还在等（wait）时由工具直接返回；否则写进请求方会话并推送。只回报一次。"""
    if not _claim_report(did):
        return
    row = _delegation_row(did)
    target = get_persona(row["to_bot"]) or {}
    text = deleg.result_text(_bot_label(target), row["status"], row["result"])
    _post_when_idle(row["from_session"], text)
    cfg = current_notify_config()
    if cfg and not _bot_muted(row["from_session"]):
        cloud_notify.notify_async(cfg, "task_completed", f"{_bot_label(target)} 完成了委托"[:120], (row["result"] or "")[:600])

def tool_send_to_bot(task_id, session_id, args, model, provider_config):
    try:
        did, _ = start_delegation(task_id, session_id, "message", args.get("bot_id"), args.get("message"),
                                  args.get("priority") or "normal", report_back=False, model=model, provider_config=provider_config)
    except (deleg.LimitError, ValueError) as e:
        return {"error": str(e)}
    return {"status": "sent", "delegation_id": did, "note": "对方会在自己的对话里处理；需要结果请用 delegate_task"}

def tool_delegate_task(task_id, session_id, args, model, provider_config):
    report_back = args.get("report_back", True) is not False
    wait = args.get("wait", True) is not False
    try:
        wait_s = int(args.get("wait_seconds") or DELEG_WAIT_DEFAULT)
    except (TypeError, ValueError):
        wait_s = DELEG_WAIT_DEFAULT
    wait_s = max(5, min(wait_s, 1800))
    try:
        did, th = start_delegation(task_id, session_id, "task", args.get("bot_id"), args.get("task"),
                                   args.get("priority") or "normal", report_back=report_back, model=model,
                                   provider_config=provider_config, waiting=wait)
    except (deleg.LimitError, ValueError) as e:
        return {"error": str(e)}
    if not wait:
        return {"status": "running", "delegation_id": did, "note": "完成后结果会自动发回这个对话" if report_back else "已交出，不回报"}
    GATE.park(task_id)
    try:
        deadline = time.time() + wait_s
        while th.is_alive() and time.time() < deadline and not is_task_cancelled(task_id):
            th.join(timeout=0.5)
    finally:
        GATE.unpark(task_id)
        with DELEG_LOCK:
            DELEG_WAITING.discard(did)
    row = _delegation_row(did)
    if row["status"] == "running":
        return {"status": "running", "delegation_id": did,
                "note": f"等了 {wait_s} 秒还没完成，" + ("结果会自动发回这个对话" if report_back else "对方会继续做完")}
    if not _claim_report(did):
        return {"status": row["status"], "delegation_id": did, "note": "结果已经发到这个对话里"}
    out = {"status": row["status"], "delegation_id": did, "bot": row["to_bot"], "result": row["result"] or ""}
    if row["status"] != "completed":
        out["error"] = f"对方任务结束状态：{row['status']}"
    return out

# ---------------- 群聊 ----------------
GROUP_FALLBACK = {}      # group_id -> (model, provider)：成员 Bot 没选自己的模型时用用户当前的模型

def _bot_provider(bot, fallback):
    if bot.get("model") and bot.get("credential"):
        provider, _st, err = resolve_provider({"protocol": "chat", "credential": bot["credential"]})
        if err:
            raise RuntimeError(f"凭据不可用：{err}")
        return bot["model"], provider
    if fallback and fallback[1]:
        return fallback
    raise RuntimeError("没有可用的模型：请给这个 Bot 选一个模型，或在手机上选好默认模型")

def _group_llm(bot, messages, fallback):
    model, provider = _bot_provider(bot, fallback)
    url = f"{provider.get('base_url', 'https://api.openai.com/v1').rstrip('/')}/chat/completions"
    resp = call_llm_with_effort(url, {"Content-Type": "application/json", "Authorization": f"Bearer {provider.get('api_key', '')}"},
                                {"model": model, "messages": messages, "stream": False, "max_tokens": 600},
                                bot.get("reasoning_effort"))
    msg = ((resp.get("choices") or [{}])[0].get("message") or {})
    text = msg.get("content") or ""
    if isinstance(text, list):
        text = "".join(p.get("text", "") for p in text if isinstance(p, dict))
    return text, (resp.get("usage") or {}).get("total_tokens") or 0

def _group_start_task(group, bot, task, msg_id):
    """群里被 @ 的 Bot 需要真正动手：在它自己的工作区跑一个任务，结果贴回群里。"""
    model, provider = _bot_provider(bot, GROUP_FALLBACK.get(group["group_id"]))
    sid = "sess_" + uuid.uuid4().hex[:12]
    tid = "task_" + uuid.uuid4().hex[:12]
    now = time.time()
    did = "grp_task_" + uuid.uuid4().hex[:8]
    content = deleg.incoming_text(f"群聊「{group['name']}」", "task", task[:20000], did, True)
    conn = get_db_connection()
    try:
        conn.execute("INSERT INTO sessions (session_id, local_session_id, title, instructions, created_at, persona_id) VALUES (?, NULL, ?, '', ?, ?)",
                     (sid, f"群聊「{group['name']}」：" + task.strip().splitlines()[0][:40], now, bot["persona_id"]))
        conn.execute("INSERT INTO tasks (task_id, session_id, client_nonce, status, model, created_at) VALUES (?, ?, NULL, 'running', ?, ?)",
                     (tid, sid, model, now))
        conn.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'user', ?, ?)", (sid, content, now))
        conn.commit()
        task_msg = cloud_groups.add_message(conn, group["group_id"], bot["persona_id"], "task", task[:2000], reply_to=msg_id,
                                            meta={"task_id": tid, "session_id": sid, "status": "running"})
    finally:
        conn.close()
    with active_tasks_lock:
        active_tasks[tid] = {"process": None, "cancelled": False, "pid": None}
    TASK_HOP[tid] = 1
    GROUPS.notify()

    def worker():
        try:
            run_agent_task(tid, sid, content, model, provider, "")
        finally:
            TASK_HOP.pop(tid, None)
            c2 = get_db_connection()
            try:
                status = (c2.execute("SELECT status FROM tasks WHERE task_id = ?", (tid,)).fetchone() or ["failed"])[0]
                last = c2.execute("SELECT content FROM messages WHERE session_id = ? AND role = 'assistant' AND content IS NOT NULL ORDER BY id DESC LIMIT 1",
                                  (sid,)).fetchone()
                result = ((last[0] if last else "") or "（没有文字结果）")[:6000]
                cloud_groups.add_message(c2, group["group_id"], bot["persona_id"], "task_result", result, reply_to=task_msg,
                                         meta={"task_id": tid, "session_id": sid, "status": status})
            finally:
                c2.close()
            GROUPS.notify()
            cfg = current_notify_config()
            if cfg and not _bot_muted(persona_id=bot["persona_id"]):
                cloud_notify.notify_async(cfg, "task_completed", f"{bot.get('name')} 在「{group['name']}」完成了任务"[:120], result[:600])

    threading.Thread(target=worker, daemon=True, name="group-task").start()
    return tid

GROUPS = cloud_groups.GroupEngine({
    "db": lambda: get_db_connection(),
    "settings": lambda: resource_settings(),
    "bot": lambda bid: get_persona(bid),
    "persona_text": lambda bot: cloud_bots.prompt(bot, []),
    "llm": lambda bot, messages, fallback: _group_llm(bot, messages, fallback),
    "start_task": lambda group, bot, task, msg_id: _group_start_task(group, bot, task, msg_id),
})

def group_payload(conn, g, after=0):
    members = []
    for bid in g["members"]:
        b = get_persona(bid)
        if b:
            members.append({"bot_id": bid, "name": b["name"], "emoji": b.get("emoji"), "model": b.get("model") or "",
                            "reasoning_effort": b.get("reasoning_effort") or ""})
    out = dict(g)
    out["member_bots"] = members
    out["typing"] = GROUPS.typing_list(g["group_id"])
    out["messages"] = cloud_groups.messages_after(conn, g["group_id"], after, 300) if after is not None else []
    return out

# 对外发消息：先以草稿形式挂起审批，用户确认后才发送（不受自定义策略影响）
ALWAYS_CONFIRM_TOOLS = {
    "send_message": {"id": "send_message_draft", "tool": "send_message", "field": "*", "pattern": ".",
                     "category": "outbound", "reason": "对外发送消息（草稿，确认后发送）"},
}

def tool_send_message(task_id, session_id, args):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    channel = args.get("channel")
    text = args.get("text")
    if not isinstance(text, str) or not text.strip():
        return {"error": "text must be a non-empty string"}
    if channel == "telegram":
        tg_channel = telegram_channel_for_task(task_id)
        if tg_channel is None:
            bot = session_bot(session_id)
            tg_channel = bot["persona_id"] if bot and telegram_config(bot["persona_id"]) else ""
        cfg = telegram_config(tg_channel)
        if not cfg:
            return {"error": "Telegram 渠道未配置"}
        chat_id = args.get("chat_id")
        allowed = cfg.get("allowed_chat_ids", [])
        if chat_id is None:
            chat_id = telegram_chat_for_task(task_id) or (allowed[0] if allowed else None)
        if not isinstance(chat_id, int) or chat_id not in allowed:
            return {"error": "chat_id 不在 Telegram 允许列表中"}
        try:
            cloud_telegram.send_text(cfg, chat_id, text)
        except cloud_telegram.TelegramAPIError as e:
            return {"error": "Telegram 发送失败：" + str(e)}
        return {"status": "sent", "channel": "telegram", "chat_id": chat_id}
    if channel == "push":
        cfg = current_notify_config()
        if not cfg:
            return {"error": "推送未配置"}
        ok, err = cloud_notify.send_now(cfg, (args.get("title") or "OpenMinis 云电脑")[:120], text, event="send_message")
        return {"status": "sent", "channel": "push"} if ok else {"error": "推送失败：" + str(err)}
    return {"error": "channel must be telegram or push"}

IMAGE_MODEL_DEFAULT = os.environ.get("OPENMINIS_IMAGE_MODEL", "gpt-image-1")
IMAGE_SIZES = ("1024x1024", "1024x1536", "1536x1024", "512x512", "auto")

def tool_image_generate(task_id, session_id, args, provider_config):
    if is_task_cancelled(task_id):
        return {"error": "Cancelled"}
    prompt = args.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return {"error": "prompt must be a non-empty string"}
    size = args.get("size") or "1024x1024"
    if size not in IMAGE_SIZES:
        return {"error": "size must be one of " + ", ".join(IMAGE_SIZES)}
    model = args.get("model") or IMAGE_MODEL_DEFAULT
    url = f"{provider_config.get('base_url', 'https://api.openai.com/v1').rstrip('/')}/images/generations"
    try:
        resp = call_llm(url, {"Content-Type": "application/json", "Authorization": f"Bearer {provider_config.get('api_key', '')}"},
                        {"model": model, "prompt": prompt[:4000], "size": size, "n": 1})
        item = (resp.get("data") or [{}])[0]
        import base64
        if item.get("b64_json"):
            png = base64.b64decode(item["b64_json"])
        elif item.get("url", "").startswith(("https://", "http://")):
            opener = urllib.request.build_opener(NoRedirect)
            with opener.open(urllib.request.Request(item["url"]), timeout=60) as r:
                png = r.read(20 * 1024 * 1024 + 1)
            if len(png) > 20 * 1024 * 1024:
                return {"error": "生成的图片超过 20MB"}
        else:
            return {"error": "图片服务没有返回 b64_json 或 url"}
    except Exception as e:
        return {"error": "图片生成失败：" + sanitize_err(e)}
    ws = get_session_workspace(session_id)
    os.makedirs(os.path.join(ws, "attachments"), exist_ok=True)
    ext = "jpg" if png[:3] == b"\xff\xd8\xff" else ("webp" if png[8:12] == b"WEBP" else "png")
    filename = f"image_{uuid.uuid4().hex[:8]}.{ext}"
    with open(os.path.join(ws, "attachments", filename), "wb") as f:
        f.write(png)
    return {"status": "ok", "action": "image_generate", "file_path": f"attachments/{filename}",
            "attachment_url": f"/v1/sessions/{session_id}/attachments/{filename}", "bytes": len(png),
            "revised_prompt": item.get("revised_prompt")}

TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "shell_execute",
            "description": "Execute shell command in isolated session workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string"},
                    "timeout": {"type": "integer"},
                    "background": {"type": "boolean", "description": "Run detached for long installs/builds; you'll be notified on completion"}
                },
                "required": ["command"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "file_read",
            "description": "Read file content from session workspace.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string"}},
                "required": ["path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "file_write",
            "description": "Write text content to file in session workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"}
                },
                "required": ["path", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "file_edit",
            "description": "Targeted edit in session workspace file via string replacement.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "old_string": {"type": "string"},
                    "new_string": {"type": "string"}
                },
                "required": ["path", "old_string", "new_string"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "browser_action",
            "description": "Control Playwright Chromium browser on persistent workspace profile.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["navigate", "get_text", "click", "type", "scroll", "screenshot", "tabs", "close_tab"]},
                    "url": {"type": "string"},
                    "selector": {"type": "string"},
                    "text": {"type": "string"},
                    "direction": {"type": "string", "enum": ["up", "down"]},
                    "amount": {"type": "integer"},
                    "full_page": {"type": "boolean"}
                },
                "required": ["action"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "desktop_action",
            "description": "Interact with VPS X11 desktop (DISPLAY=:99) using scrot / xdotool.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["screenshot", "click", "mouse_move", "type", "key"]},
                    "x": {"type": "integer"},
                    "y": {"type": "integer"},
                    "text": {"type": "string"},
                    "key": {"type": "string"},
                    "button": {"type": "integer"}
                },
                "required": ["action"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "background_jobs",
            "description": "List, check, read the log tail of, or stop your background shell commands.",
            "parameters": {
                "type": "object",
                "properties": {"action": {"type": "string", "enum": ["list", "status", "log", "stop"]}, "job_id": {"type": "string"}},
                "required": ["action"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "request_user_takeover",
            "description": "Ask the user to take over the cloud desktop on their phone for a step only they can do (login, password, captcha, QR scan, payment confirmation). After calling, end your turn; the user replies '我完成了' when done.",
            "parameters": {
                "type": "object",
                "properties": {"reason": {"type": "string", "description": "What the user should do, in Chinese, one sentence"}},
                "required": ["reason"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "memory_write",
            "description": "Save one long-term memory entry (shared with the user's phone). Keep it concise and self-contained; never store secrets.",
            "parameters": {
                "type": "object",
                "properties": {
                    "content": {"type": "string", "description": "Concise Markdown, ideally with a short '## Topic' heading."},
                    "category": {"type": "string", "enum": list(cloud_memory.CATEGORIES), "description": "profile / rules / people / workstreams / note (default note)."}
                },
                "required": ["content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "memory_search",
            "description": "Full-text search over the user's long-term memory (phone daily logs, GLOBAL.md and cloud entries). Space-separated keywords; Chinese substrings work. Empty query returns the most recent entries.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "category": {"type": "string", "enum": list(cloud_memory.CATEGORIES)},
                    "limit": {"type": "integer", "description": "1-50, default 10"}
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "skill_load",
            "description": "Load the full SKILL.md of one skill from the index in the system prompt. Call it before following a skill.",
            "parameters": {
                "type": "object",
                "properties": {"name": {"type": "string", "description": "Exact skill name from the index."}},
                "required": ["name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "page_write",
            "description": "Save a report / dashboard / small interactive tool as an HTML page in the user's Pages library (viewable on the phone). Pass page_id to update an existing page.",
            "parameters": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "html": {"type": "string", "description": "Full HTML document or a body fragment; inline CSS/JS only, max 2MB."},
                    "page_id": {"type": "string", "description": "Existing page_id to update (optional)."}
                },
                "required": ["title", "html"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "subagent_task",
            "description": "Delegate one self-contained sub task to a sub agent with its own fresh session and the same tools; blocks until it finishes and returns its final answer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "task": {"type": "string", "description": "Complete instructions; the sub agent cannot see this conversation."},
                    "title": {"type": "string", "description": "Short label."},
                    "persona": {"type": "string", "description": "Optional persona_id: run the sub agent as another persona (its instructions and private memory) to consult that bot. Defaults to the current persona."}
                },
                "required": ["task"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "image_generate",
            "description": "Generate an image with the provider's /images/generations endpoint and save it under attachments/.",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string"},
                    "size": {"type": "string", "enum": list(IMAGE_SIZES)},
                    "model": {"type": "string", "description": "Image model (default from OPENMINIS_IMAGE_MODEL or gpt-image-1)."}
                },
                "required": ["prompt"]
            }
        }
    }
]

TOOL_DEFINITIONS.append({
    "type": "function",
    "function": {
        "name": "send_message",
        "description": "Send a message to the user through Telegram or their push service. Every call is shown to the user as a draft and only sent after they approve it.",
        "parameters": {
            "type": "object",
            "properties": {
                "channel": {"type": "string", "enum": ["telegram", "push"]},
                "text": {"type": "string"},
                "title": {"type": "string", "description": "Push title (push only)."},
                "chat_id": {"type": "integer", "description": "Telegram chat id from the allow list (default: the chat this task came from, else the first allowed chat)."}
            },
            "required": ["channel", "text"]
        }
    }
})

TOOL_DEFINITIONS.extend([
    {"type": "function", "function": {
        "name": "list_bots",
        "description": "List the user's other Bots (id, name, description, model, whether busy) so you can message or delegate to them.",
        "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {
        "name": "send_to_bot",
        "description": "Send a one-way message to another Bot. It handles it in its own conversation (marked as from you); nothing comes back. Use delegate_task when you need a result.",
        "parameters": {"type": "object", "properties": {
            "bot_id": {"type": "string"},
            "message": {"type": "string"},
            "priority": {"type": "string", "enum": ["normal", "high"]}},
            "required": ["bot_id", "message"]}}},
    {"type": "function", "function": {
        "name": "delegate_task",
        "description": "Hand a self-contained task to another Bot. It runs in that Bot's own workspace, model and memory. By default waits for the result (up to wait_seconds) and returns it; if it takes longer, the result is posted back into this conversation when done.",
        "parameters": {"type": "object", "properties": {
            "bot_id": {"type": "string"},
            "task": {"type": "string", "description": "Complete instructions; the other Bot cannot see this conversation."},
            "report_back": {"type": "boolean", "description": "Send the result back to you (default true)."},
            "wait": {"type": "boolean", "description": "Block until done (default true). false = continue now, result arrives later."},
            "wait_seconds": {"type": "integer", "description": "Max seconds to wait (5-1800, default 600)."},
            "priority": {"type": "string", "enum": ["normal", "high"]}},
            "required": ["bot_id", "task"]}}},
])

DELEGATION_TOOLS = {"send_to_bot", "delegate_task"}

def tools_for_depth(depth):
    if depth >= 1:
        return [t for t in TOOL_DEFINITIONS if t["function"]["name"] not in DELEGATION_TOOLS | {"subagent_task"}]
    return TOOL_DEFINITIONS

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "Redirection prohibited", headers, fp)

TASK_EFFORT = {}          # task_id -> 本次任务的思考深度（例行任务覆盖、客户端指定）
_EFFORT_UNSUPPORTED = set()  # (base_url, model)：服务商拒绝思考参数后不再发送

def apply_reasoning(body, model, effort, chat_url):
    """把思考深度映射成服务商参数：Claude 系（OpenAI 兼容层）用 thinking.budget_tokens，
    其余（OpenAI / Gemini 兼容 / 大多数中转）用 reasoning_effort。off 或不支持时不发送。"""
    if not effort or effort == "off" or (chat_url, model) in _EFFORT_UNSUPPORTED:
        return body
    out = dict(body)
    name = (model or "").lower()
    if "claude" in name:
        budget = {"low": 2048, "medium": 8192, "high": 24576, "xhigh": 48000}[effort]
        out["thinking"] = {"type": "enabled", "budget_tokens": budget}
        out["max_tokens"] = max(int(out.get("max_tokens") or 0), budget + 4096)
    else:
        out["reasoning_effort"] = effort
    return out

def call_llm_with_effort(url, headers, body, effort):
    payload = apply_reasoning(body, body.get("model"), effort, url)
    if payload is body:
        return call_llm(url, headers, body)
    try:
        return call_llm(url, headers, payload)
    except urllib.error.HTTPError as e:
        if e.code not in (400, 422):
            raise
        # 模型不支持思考参数（或不支持 xhigh）：降级一次，再不行就不发送
        if effort == "xhigh" and "claude" not in (body.get("model") or "").lower():
            try:
                return call_llm(url, headers, apply_reasoning(body, body.get("model"), "high", url))
            except urllib.error.HTTPError as e2:
                if e2.code not in (400, 422):
                    raise
        _EFFORT_UNSUPPORTED.add((url, body.get("model")))
        return call_llm(url, headers, body)

def call_llm(url, headers, body):
    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with opener.open(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))

def run_agent_task(task_id, session_id, initial_content, model, provider_config, instructions, depth=0):
    """顶层任务先排队：同一 Bot 的并发数、全局并发数、同时运行的 Bot 数都来自资源设置；子代理在父任务的名额里运行。"""
    if depth > 0:
        return _run_agent_task_inner(task_id, session_id, initial_content, model, provider_config, instructions, depth)
    lane = task_lane(session_id)
    bot_id = session_persona_id(session_id)

    def queued(pos):
        log_event(task_id, "queued", {"position": pos, "message": f"排队中（第 {pos} 位）"})

    slot = GATE.acquire(task_id, lane, bot_id, cancelled=lambda: is_task_cancelled(task_id), on_queued=queued,
                        priority=TASK_PRIORITY.get(task_id, "normal"))
    if slot is None:
        # 排队时被取消（含上游委托方取消）：把状态落到数据库
        conn = get_db_connection()
        try:
            conn.execute("UPDATE tasks SET status = 'cancelled' WHERE task_id = ? AND status IN ('running', 'waiting_user')", (task_id,))
            conn.commit()
        finally:
            conn.close()
        log_event(task_id, "cancelled", {"message": "排队时已取消"})
        return None
    timer = None
    try:
        if slot:
            ACTIVE_SLOTS[session_id] = slot
        limit = iso.bot_settings(resource_settings(), bot_id).get("task_timeout_min") or 0
        if limit:
            def expire():
                log_event(task_id, "error", {"error": f"任务超过 {limit} 分钟上限，已停止"})
                set_task_cancelled(task_id)
            timer = threading.Timer(limit * 60, expire)
            timer.daemon = True
            timer.start()
        return _run_agent_task_inner(task_id, session_id, initial_content, model, provider_config, instructions, depth)
    finally:
        if timer:
            timer.cancel()
        ACTIVE_SLOTS.pop(session_id, None)
        if bot_id and slot:
            key = f"{bot_id}:{slot}"
            if DISPLAYS.info(key):
                DISPLAYS.stop(key)
        GATE.release(task_id)

def _run_agent_task_inner(task_id, session_id, initial_content, model, provider_config, instructions, depth=0):
    api_key = provider_config.get("api_key", "")
    chat_url = f"{provider_config.get('base_url', 'https://api.openai.com/v1').rstrip('/')}/chat/completions"

    if is_task_cancelled(task_id):
        return

    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT status FROM tasks WHERE task_id = ?", (task_id,))
    r = c.fetchone()
    if not r or r[0] == 'cancelled':
        conn.close()
        return

    # Retrieve all session messages for LLM context
    c.execute("SELECT role, content, tool_calls, tool_call_id FROM messages WHERE session_id = ? ORDER BY id ASC", (session_id,))
    rows = c.fetchall()
    conn.close()

    plugin_defs, plugin_map, plugin_note = plugin_tools_for_session(session_id, depth)
    system_text = persona_prompt(session_id) + (instructions or "") + server_tool_notes(session_id) + plugin_note + mention_note(session_id, initial_content)
    messages = [{"role": "system", "content": system_text.lstrip()}]
    for r_role, r_content, r_tc, r_tcid in rows:
        m = {"role": r_role}
        if r_content is not None:
            decoded_content = r_content
            if r_role in ('user', 'assistant') and isinstance(r_content, str) and r_content.startswith('['):
                try:
                    candidate = json.loads(r_content)
                    if isinstance(candidate, list) and all(isinstance(part, dict) and part.get('type') in ('text', 'image_url') for part in candidate):
                        decoded_content = candidate
                except (ValueError, TypeError):
                    pass
            m["content"] = decoded_content
        if r_tc:
            try: m["tool_calls"] = json.loads(r_tc)
            except: pass
        if r_tcid:
            m["tool_call_id"] = r_tcid
        messages.append(m)

    _bot = session_bot(session_id)
    effort = TASK_EFFORT.pop(task_id, None) or (_bot or {}).get("reasoning_effort")
    log_event(task_id, "started", {"message": "Started", "model": model, "reasoning_effort": effort})
    final_status = "completed"

    try:
        for _ in range(MAX_TURNS):
            if is_task_cancelled(task_id):
                final_status = "cancelled"
                break
            try:
                resp = call_llm_with_effort(chat_url, {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}, {
                    "model": model, "messages": messages, "tools": tools_for_depth(depth) + plugin_defs, "tool_choice": "auto", "stream": False
                }, effort)
            except Exception as e:
                log_event(task_id, "error", {"error": sanitize_err(e)})
                final_status = "failed"
                break

            choices = resp.get("choices", [])
            if not choices:
                log_event(task_id, "error", {"error": "Missing choices"})
                final_status = "failed"
                break

            msg = choices[0].get("message", {})
            content = msg.get("content")
            tool_calls = msg.get("tool_calls")

            if not content and not tool_calls:
                log_event(task_id, "error", {"error": "Empty model response"})
                final_status = "failed"
                break

            if content and not tool_calls:
                log_event(task_id, "thought", {"content": content})
                messages.append({"role": "assistant", "content": content})
                conn = get_db_connection()
                c = conn.cursor()
                c.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)", (session_id, "assistant", content, time.time()))
                conn.commit()
                conn.close()

            if tool_calls:
                ast_msg = {"role": "assistant"}
                if content:
                    ast_msg["content"] = content
                    log_event(task_id, "thought", {"content": content})
                else:
                    ast_msg["content"] = None
                ast_msg["tool_calls"] = tool_calls
                messages.append(ast_msg)

                conn = get_db_connection()
                c = conn.cursor()
                c.execute("INSERT INTO messages (session_id, role, content, tool_calls, timestamp) VALUES (?, ?, ?, ?, ?)", 
                          (session_id, "assistant", content, json.dumps(tool_calls, ensure_ascii=False), time.time()))
                conn.commit()
                conn.close()

                for tc in tool_calls:
                    if is_task_cancelled(task_id):
                        final_status = "cancelled"
                        break
                    tc_id = tc.get("id")
                    fn = tc.get("function", {})
                    fn_name = fn.get("name")
                    try: fn_args = json.loads(fn.get("arguments", "{}"))
                    except: fn_args = {}

                    log_event(task_id, "tool_call", {"id": tc_id, "tool": fn_name, "arguments": fn_args})
                    if is_task_cancelled(task_id):
                        final_status = "cancelled"
                        break

                    policy = current_approval_policy()
                    hit = cloud_policy.evaluate(fn_name, fn_args, policy)
                    if not hit and fn_name in ALWAYS_CONFIRM_TOOLS:
                        hit = ALWAYS_CONFIRM_TOOLS[fn_name]
                    if not hit and fn_name in plugin_map and PLUGINS.needs_confirm(*plugin_map[fn_name]):
                        hit = {"id": "plugin_confirm", "tool": fn_name, "field": "*", "pattern": ".", "category": "outbound",
                               "reason": f"插件 {plugin_map[fn_name][0]} 的写操作 {plugin_map[fn_name][1]}"}
                    decision = None
                    if hit:
                        decision = request_approval(task_id, session_id, tc_id, fn_name, fn_args, hit, policy.get("timeout_seconds", 1800))
                        if decision == "cancelled" or is_task_cancelled(task_id):
                            final_status = "cancelled"
                            break

                    if hit and decision != "approved":
                        label = {"denied": "用户拒绝", "expired": "审批超时未获批准"}.get(decision, decision)
                        res = {"error": f"{label}，未执行：{hit['reason']}", "approval": decision, "rule_id": hit["id"]}
                    elif fn_name == "shell_execute": res = tool_shell_execute(task_id, session_id, fn_args)
                    elif fn_name == "file_read": res = tool_file_read(task_id, session_id, fn_args)
                    elif fn_name == "file_write": res = tool_file_write(task_id, session_id, fn_args)
                    elif fn_name == "file_edit": res = tool_file_edit(task_id, session_id, fn_args)
                    elif fn_name == "browser_action": res = tool_browser_action(task_id, session_id, fn_args)
                    elif fn_name == "desktop_action": res = tool_desktop_action(task_id, session_id, fn_args)
                    elif fn_name == "request_user_takeover": res = tool_request_user_takeover(task_id, session_id, fn_args)
                    elif fn_name == "background_jobs": res = tool_background_jobs(task_id, session_id, fn_args)
                    elif fn_name == "memory_write": res = tool_memory_write(task_id, session_id, fn_args)
                    elif fn_name == "memory_search": res = tool_memory_search(task_id, session_id, fn_args)
                    elif fn_name == "skill_load": res = tool_skill_load(task_id, session_id, fn_args)
                    elif fn_name == "page_write": res = tool_page_write(task_id, session_id, fn_args)
                    elif fn_name == "subagent_task": res = tool_subagent_task(task_id, session_id, fn_args, model, provider_config, depth)
                    elif fn_name == "list_bots": res = tool_list_bots(task_id, session_id, fn_args)
                    elif fn_name == "send_to_bot" and depth == 0: res = tool_send_to_bot(task_id, session_id, fn_args, model, provider_config)
                    elif fn_name == "delegate_task" and depth == 0: res = tool_delegate_task(task_id, session_id, fn_args, model, provider_config)
                    elif fn_name == "image_generate": res = tool_image_generate(task_id, session_id, fn_args, provider_config)
                    elif fn_name == "send_message": res = tool_send_message(task_id, session_id, fn_args)
                    elif fn_name in plugin_map:
                        res = PLUGINS.call(plugin_map[fn_name][0], plugin_map[fn_name][1], fn_args)
                        if isinstance(res, dict) and res.get("error") == "needs_auth":
                            log_event(task_id, "auth_required", {"plugin": res.get("plugin"), "message": res.get("message")})
                    else: res = {"error": f"Unknown tool {fn_name}"}

                    log_event(task_id, "tool_result", {"id": tc_id, "tool": fn_name, "result": res})
                    
                    # Tool result formatting: If screenshot produced, include attachment path and format
                    tool_content_str = json.dumps(res, ensure_ascii=False)
                    messages.append({"role": "tool", "tool_call_id": tc_id, "content": tool_content_str})

                    # If model is vision-capable (e.g. gpt-4o, claude-3, gemini-1.5, qwen-vl) and screenshot generated, inject vision user message
                    if isinstance(res, dict) and res.get("status") == "ok" and res.get("action") == "screenshot":
                        rel_file = res.get("file_path")
                        if rel_file:
                            ws = get_session_workspace(session_id)
                            abs_img = os.path.join(ws, rel_file)
                            if os.path.exists(abs_img) and os.path.getsize(abs_img) <= 2 * 1024 * 1024:
                                import base64
                                with open(abs_img, "rb") as im_f:
                                    img_b64 = base64.b64encode(im_f.read()).decode("utf-8")
                                # Append user vision observation for multimodal model comprehension
                                vision_user_msg = {
                                    "role": "user",
                                    "content": [
                                        {"type": "text", "text": f"[Browser/Desktop Screenshot Observation: {rel_file}]"},
                                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}}
                                    ]
                                }
                                messages.append(vision_user_msg)

                    conn = get_db_connection()
                    c = conn.cursor()
                    c.execute("INSERT INTO messages (session_id, role, content, tool_call_id, timestamp) VALUES (?, ?, ?, ?, ?)",
                              (session_id, "tool", tool_content_str, tc_id, time.time()))
                    conn.commit()
                    conn.close()

                if final_status == "cancelled":
                    break
            else:
                break
        else:
            final_status = "limit_reached"
            log_event(task_id, "limit_reached", {"message": f"Reached {MAX_TURNS} turns"})
    except Exception as e:
        if is_task_cancelled(task_id):
            final_status = "cancelled"
        else:
            log_event(task_id, "error", {"error": sanitize_err(e)})
            final_status = "failed"
    finally:
        if is_task_cancelled(task_id):
            final_status = "cancelled"
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("UPDATE tasks SET status = ? WHERE task_id = ? AND status IN ('running', 'waiting_user')", (final_status, task_id))
        conn.commit()
        conn.close()
        with active_tasks_lock:
            active_tasks.pop(task_id, None)
        try:
            if depth == 0:
                on_task_finished(task_id, session_id, final_status)
        except Exception as e:
            print(f"task notify failed: {type(e).__name__}")

# ======================= 云端例行任务 (Routines) =======================
ROUTINE_ID_RE = re.compile(r'^rtn_[a-f0-9]{12}$')
SCHEDULER_TICK = float(os.environ.get("OPENMINIS_SCHEDULER_TICK", "15"))
MIN_INTERVAL_SECONDS = int(os.environ.get("OPENMINIS_MIN_INTERVAL", "60"))
ROUTINE_DEFAULT_INSTRUCTIONS = (
    "你是 OpenMinis 云端 Agent，正在用户的 Linux 云电脑上执行一个无人值守的例行任务。"
    "用户此时可能不在线：不要等待对话回复，独立完成任务并以简洁中文给出最终结果摘要。"
    "风险操作会触发审批，用户批准前任务暂停；被拒绝或超时时换用安全做法或说明无法完成。"
    "只能调用本次实际提供的工具，所有结论以工具真实输出为准，不要声称未执行的操作已经完成。"
)
_scheduler_stop = threading.Event()
_scheduler_thread = None

def _routine_row_to_dict(r):
    keys = ["routine_id", "name", "prompt", "schedule", "credential", "model", "instructions", "enabled",
            "max_runs", "run_count", "next_run_at", "last_run_at", "last_status", "notify", "created_at", "updated_at", "persona_id",
            "reasoning_effort"]
    d = dict(zip(keys, r))
    try: d["schedule"] = json.loads(d["schedule"])
    except Exception: d["schedule"] = {}
    d["enabled"] = bool(d["enabled"])
    d["notify"] = bool(d["notify"])
    return d

ROUTINE_COLUMNS = "routine_id, name, prompt, schedule, credential, model, instructions, enabled, max_runs, run_count, next_run_at, last_run_at, last_status, notify, created_at, updated_at, persona_id, reasoning_effort"

def validate_schedule(schedule):
    """返回规范化的 schedule dict，非法抛 ValueError。"""
    if not isinstance(schedule, dict):
        raise ValueError("schedule must be an object")
    kind = schedule.get("kind")
    if kind == "cron":
        expr = schedule.get("expr")
        tz = schedule.get("timezone") or "UTC"
        try:
            spec = cloud_cron.CronSpec(expr)
            cloud_cron.validate_timezone(tz)
        except cloud_cron.CronError as e:
            raise ValueError(str(e))
        if spec.next_after(time.time(), tz) is None:
            raise ValueError("cron expression never fires")
        return {"kind": "cron", "expr": spec.expr, "timezone": tz}
    if kind == "interval":
        seconds = schedule.get("seconds")
        if not isinstance(seconds, int) or isinstance(seconds, bool) or seconds < MIN_INTERVAL_SECONDS or seconds > 366 * 86400:
            raise ValueError(f"interval seconds must be an integer between {MIN_INTERVAL_SECONDS} and {366 * 86400}")
        return {"kind": "interval", "seconds": seconds}
    if kind == "once":
        at = schedule.get("at")
        if not isinstance(at, (int, float)) or isinstance(at, bool):
            raise ValueError("once.at must be a UNIX timestamp")
        return {"kind": "once", "at": float(at)}
    raise ValueError("schedule.kind must be cron, interval or once")

def compute_next_run(schedule, after_ts, first=False):
    kind = schedule["kind"]
    if kind == "cron":
        return cloud_cron.CronSpec(schedule["expr"]).next_after(after_ts, schedule.get("timezone", "UTC"))
    if kind == "interval":
        return after_ts + schedule["seconds"]
    if kind == "once":
        return schedule["at"] if first else None
    return None

def get_routine(routine_id):
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT " + ROUTINE_COLUMNS + " FROM routines WHERE routine_id = ?", (routine_id,))
        r = c.fetchone()
    finally:
        conn.close()
    return _routine_row_to_dict(r) if r else None

def list_routines():
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT " + ROUTINE_COLUMNS + " FROM routines ORDER BY created_at ASC")
        return [_routine_row_to_dict(r) for r in c.fetchall()]
    finally:
        conn.close()

def list_routine_runs(routine_id, limit=20):
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT run_id, task_id, session_id, trigger, status, result, error, started_at, finished_at FROM routine_runs WHERE routine_id = ? ORDER BY started_at DESC LIMIT ?",
                  (routine_id, limit))
        keys = ["run_id", "task_id", "session_id", "trigger", "status", "result", "error", "started_at", "finished_at"]
        return [dict(zip(keys, r)) for r in c.fetchall()]
    finally:
        conn.close()

def validate_routine_fields(req, existing=None):
    """返回待写入字段 dict；非法抛 ValueError。existing 为 None 时为新建（必填项校验）。"""
    out = {}
    def text(key, max_len, required):
        if key in req:
            v = req[key]
            if not isinstance(v, str) or not v.strip() or len(v) > max_len:
                raise ValueError(f"{key} must be a non-empty string (max {max_len})")
            out[key] = v.strip() if key != "prompt" else v
        elif required and existing is None:
            raise ValueError(f"{key} is required")
    text("name", 120, True)
    text("prompt", 20000, True)
    text("model", 200, True)
    text("credential", 64, True)
    if "credential" in out and not CREDENTIAL_NAME_RE.match(out["credential"]):
        raise ValueError("Invalid credential name")
    if "instructions" in req:
        v = req["instructions"]
        if v is not None and (not isinstance(v, str) or len(v) > 50000):
            raise ValueError("instructions must be a string (max 50000)")
        out["instructions"] = v
    if "schedule" in req:
        out["schedule"] = validate_schedule(req["schedule"])
    elif existing is None:
        raise ValueError("schedule is required")
    for key in ("enabled", "notify"):
        if key in req:
            if not isinstance(req[key], bool):
                raise ValueError(f"{key} must be a boolean")
            out[key] = req[key]
    if "persona_id" in req:
        out["persona_id"] = validate_persona_ref(req["persona_id"])
    if "reasoning_effort" in req:
        v = req["reasoning_effort"]
        if v not in (None, "") and v not in cloud_bots.EFFORTS:
            raise ValueError("reasoning_effort must be one of off/low/medium/high/xhigh or null")
        out["reasoning_effort"] = v or None
    if "max_runs" in req:
        v = req["max_runs"]
        if v is not None and (not isinstance(v, int) or isinstance(v, bool) or v < 1):
            raise ValueError("max_runs must be a positive integer or null")
        out["max_runs"] = v
    return out

def create_routine(fields):
    now = time.time()
    rid = "rtn_" + uuid.uuid4().hex[:12]
    schedule = fields["schedule"]
    enabled = fields.get("enabled", True)
    next_run = compute_next_run(schedule, now, first=True) if enabled else None
    conn = get_db_connection()
    try:
        conn.execute("INSERT INTO routines (" + ROUTINE_COLUMNS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NULL, NULL, ?, ?, ?, ?, ?)",
                     (rid, fields["name"], fields["prompt"], json.dumps(schedule), fields["credential"], fields["model"],
                      fields.get("instructions"), 1 if enabled else 0, fields.get("max_runs"), next_run,
                      1 if fields.get("notify", True) else 0, now, now, fields.get("persona_id"), fields.get("reasoning_effort")))
        conn.commit()
    finally:
        conn.close()
    return get_routine(rid)

def update_routine(routine_id, fields):
    current = get_routine(routine_id)
    if not current:
        return None
    merged = dict(current)
    merged.update(fields)
    now = time.time()
    if "schedule" in fields or "enabled" in fields:
        merged["next_run_at"] = compute_next_run(merged["schedule"], now, first=True) if merged["enabled"] else None
        if merged["schedule"]["kind"] == "once" and merged["enabled"] and merged["next_run_at"] is None:
            merged["enabled"] = False
    conn = get_db_connection()
    try:
        conn.execute("UPDATE routines SET name = ?, prompt = ?, schedule = ?, credential = ?, model = ?, instructions = ?, enabled = ?, max_runs = ?, next_run_at = ?, notify = ?, updated_at = ?, persona_id = ?, reasoning_effort = ? WHERE routine_id = ?",
                     (merged["name"], merged["prompt"], json.dumps(merged["schedule"]), merged["credential"], merged["model"],
                      merged.get("instructions"), 1 if merged["enabled"] else 0, merged.get("max_runs"), merged["next_run_at"],
                      1 if merged["notify"] else 0, now, merged.get("persona_id"), merged.get("reasoning_effort"), routine_id))
        conn.commit()
    finally:
        conn.close()
    return get_routine(routine_id)

def delete_routine(routine_id):
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("DELETE FROM routines WHERE routine_id = ?", (routine_id,))
        deleted = c.rowcount > 0
        conn.commit()
        return deleted
    finally:
        conn.close()

def _finish_routine_run(run_id, routine_id, status, result=None, error=None):
    now = time.time()
    conn = get_db_connection()
    try:
        conn.execute("UPDATE routine_runs SET status = ?, result = ?, error = ?, finished_at = ? WHERE run_id = ?",
                     (status, result, error, now, run_id))
        conn.execute("UPDATE routines SET last_status = ? WHERE routine_id = ?", (status, routine_id))
        conn.commit()
    finally:
        conn.close()

def on_routine_finished(routine, run):
    """例行任务结束时推送，异常不影响调度。"""
    if not routine.get("notify", True) or run.get("status") == "skipped" or _bot_muted(persona_id=routine.get("persona_id") or ""):
        return None
    cfg = current_notify_config()
    if not cfg:
        return None
    label = {"completed": "完成", "failed": "失败", "limit_reached": "达到轮数上限", "cancelled": "已取消",
             "interrupted": "中断"}.get(run.get("status"), run.get("status"))
    body = (run.get("result") or run.get("error") or "（无文字结果）").strip()[:600]
    cloud_notify.notify_async(cfg, "routine_finished", f"例行任务「{routine['name']}」{label}"[:120], body)

def launch_routine_run(routine, trigger="schedule"):
    """启动一次例行任务。返回 run dict（含 run_id / task_id / status）。"""
    run_id = "run_" + uuid.uuid4().hex[:12]
    now = time.time()
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("SELECT run_id FROM routine_runs WHERE routine_id = ? AND status IN ('running', 'waiting_user')", (routine["routine_id"],))
        active = c.fetchone()
        status = "skipped" if active else "running"
        c.execute("INSERT INTO routine_runs (run_id, routine_id, task_id, session_id, trigger, status, result, error, started_at, finished_at) VALUES (?, ?, NULL, NULL, ?, ?, NULL, ?, ?, ?)",
                  (run_id, routine["routine_id"], trigger, status, "上一次运行尚未结束，本次跳过" if active else None, now, now if active else None))
        c.execute("UPDATE routines SET last_run_at = ?, run_count = run_count + ? WHERE routine_id = ?", (now, 0 if active else 1, routine["routine_id"]))
        conn.commit()
    finally:
        conn.close()
    if active:
        return {"run_id": run_id, "status": "skipped", "task_id": None}

    provider, p_status, p_err = resolve_provider({"credential": routine["credential"]})
    if p_err:
        err = f"凭据不可用（{p_status}）：{p_err}"
        _finish_routine_run(run_id, routine["routine_id"], "failed", error=err)
        run = {"run_id": run_id, "status": "failed", "task_id": None, "error": err, "trigger": trigger}
        try: on_routine_finished(routine, run)
        except Exception: pass
        return run

    sid = "sess_" + uuid.uuid4().hex[:12]
    tid = "task_" + uuid.uuid4().hex[:12]
    if routine.get("reasoning_effort"):
        TASK_EFFORT[tid] = routine["reasoning_effort"]
    instructions = routine.get("instructions") or ROUTINE_DEFAULT_INSTRUCTIONS
    fired = time.strftime("%Y-%m-%d %H:%M:%S %z", time.localtime(now))
    content = f"[例行任务「{routine['name']}」于 {fired} 触发（{'手动运行' if trigger == 'manual' else '按计划'}）]\n{routine['prompt']}"
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("INSERT INTO sessions (session_id, local_session_id, title, instructions, created_at, persona_id) VALUES (?, NULL, ?, ?, ?, ?)",
                  (sid, "例行任务：" + routine["name"], instructions, now, routine.get("persona_id")))
        c.execute("INSERT INTO tasks (task_id, session_id, client_nonce, status, model, created_at) VALUES (?, ?, NULL, 'running', ?, ?)",
                  (tid, sid, routine["model"], now))
        c.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'user', ?, ?)", (sid, content, now))
        c.execute("UPDATE routine_runs SET task_id = ?, session_id = ? WHERE run_id = ?", (tid, sid, run_id))
        conn.commit()
    finally:
        conn.close()
    with active_tasks_lock:
        active_tasks[tid] = {"process": None, "cancelled": False, "pid": None}

    def worker():
        try:
            run_agent_task(tid, sid, content, routine["model"], provider, instructions)
        finally:
            conn2 = get_db_connection()
            try:
                c2 = conn2.cursor()
                c2.execute("SELECT status FROM tasks WHERE task_id = ?", (tid,))
                row = c2.fetchone()
                final = row[0] if row else "failed"
                c2.execute("SELECT content FROM messages WHERE session_id = ? AND role = 'assistant' AND content IS NOT NULL ORDER BY id DESC LIMIT 1", (sid,))
                last = c2.fetchone()
                c2.execute("SELECT payload FROM task_events WHERE task_id = ? AND event_type = 'error' ORDER BY id DESC LIMIT 1", (tid,))
                err_row = c2.fetchone()
            finally:
                conn2.close()
            err = None
            if err_row:
                try: err = json.loads(err_row[0]).get("error")
                except Exception: err = err_row[0]
            result = last[0][:20000] if last else None
            _finish_routine_run(run_id, routine["routine_id"], final, result=result, error=err)
            try:
                on_routine_finished(routine, {"run_id": run_id, "task_id": tid, "session_id": sid, "status": final,
                                              "result": result, "error": err, "trigger": trigger})
            except Exception:
                pass

    threading.Thread(target=worker, daemon=True).start()
    return {"run_id": run_id, "status": "running", "task_id": tid, "session_id": sid}

def scheduler_tick(now=None):
    """认领到期的例行任务并启动；返回启动的 run 列表。"""
    now = time.time() if now is None else now
    claimed = []
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("BEGIN IMMEDIATE")
        c.execute("SELECT " + ROUTINE_COLUMNS + " FROM routines WHERE enabled = 1 AND next_run_at IS NOT NULL AND next_run_at <= ?", (now,))
        for row in c.fetchall():
            routine = _routine_row_to_dict(row)
            # 停机期间错过的多次触发只补跑一次，下一次从现在起算
            next_run = compute_next_run(routine["schedule"], now)
            enabled = 1
            if next_run is None:
                enabled = 0
            if routine.get("max_runs") is not None and routine["run_count"] + 1 >= routine["max_runs"]:
                enabled, next_run = 0, None
            c.execute("UPDATE routines SET next_run_at = ?, enabled = ? WHERE routine_id = ?", (next_run, enabled, routine["routine_id"]))
            claimed.append(routine)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    runs = []
    for routine in claimed:
        try:
            runs.append(launch_routine_run(routine, "schedule"))
        except Exception as e:
            sys.stderr.write(f"[routine] launch failed {routine['routine_id']}: {sanitize_err(e)}\n")
    return runs

def _scheduler_main():
    while not _scheduler_stop.wait(SCHEDULER_TICK):
        try:
            scheduler_tick()
        except Exception as e:
            sys.stderr.write(f"[routine] scheduler error: {sanitize_err(e)}\n")

def start_scheduler():
    global _scheduler_thread
    if _scheduler_thread and _scheduler_thread.is_alive():
        return
    _scheduler_stop.clear()
    _scheduler_thread = threading.Thread(target=_scheduler_main, name="routine-scheduler", daemon=True)
    _scheduler_thread.start()

def stop_scheduler():
    _scheduler_stop.set()
    t = _scheduler_thread
    if t:
        t.join(timeout=5)

# ======================= Telegram 渠道 =======================
TELEGRAM_POLL_TIMEOUT = int(os.environ.get("OPENMINIS_TELEGRAM_POLL_TIMEOUT", "25"))
TELEGRAM_DEFAULT_INSTRUCTIONS = (
    "你是 OpenMinis 云端 Agent，用户正通过 Telegram 与你对话，你运行在用户的 Linux 云电脑上。"
    "回复会以纯文本发到 Telegram：用简洁中文，少用 Markdown 表格；长结果可用 page_write 保存为页面后告诉用户标题。"
)
TELEGRAM_HELP = ("OpenMinis 云电脑已连接。直接发消息即可让云端 Agent 干活。\n"
                 "/new 开始新会话\n/stop 停止当前任务\n/status 查看当前任务状态")
_telegram_stop = threading.Event()
_telegram_threads = {}   # channel（"" = 共享渠道，否则为 bot_id）-> Thread
_telegram_statuses = {}  # channel -> 状态
_telegram_warned_chats = set()

def _tg_status(channel):
    return _telegram_statuses.setdefault(channel, {"running": False, "last_poll_at": None, "last_error": None, "handled": 0})

_telegram_status = _tg_status("")

def telegram_setting_name(channel=""):
    return cloud_telegram.SETTING_NAME + (":" + channel if channel else "")

def telegram_config(channel=""):
    conn = get_db_connection()
    try:
        cfg = cloud_notify.load_setting(conn, telegram_setting_name(channel))
    except Exception as e:
        _tg_status(channel)["last_error"] = "config: " + type(e).__name__
        return None
    finally:
        conn.close()
    if cfg is not None:
        cfg["_channel"] = channel
    return cfg

def telegram_bot_channels():
    conn = get_db_connection()
    try:
        rows = conn.execute("SELECT name FROM secure_settings WHERE name LIKE ?", (cloud_telegram.SETTING_NAME + ":%",)).fetchall()
    finally:
        conn.close()
    return [r[0].split(":", 1)[1] for r in rows]

def telegram_channel_for_task(task_id):
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT channel FROM telegram_tasks WHERE task_id = ?", (task_id,)).fetchone()
        return (row[0] or "") if row else None
    finally:
        conn.close()

def _telegram_state(key, value=None):
    conn = get_db_connection()
    try:
        if value is None:
            row = conn.execute("SELECT value FROM telegram_state WHERE key = ?", (key,)).fetchone()
            return row[0] if row else None
        conn.execute("INSERT INTO telegram_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, str(value)))
        conn.commit()
    finally:
        conn.close()

def telegram_session_for(cfg, chat_id, title_hint, new=False):
    channel = cfg.get("_channel") or ""
    conn = get_db_connection()
    try:
        c = conn.cursor()
        if channel:
            row = c.execute("SELECT session_id FROM telegram_bot_chats WHERE channel = ? AND chat_id = ?", (channel, chat_id)).fetchone()
        else:
            row = c.execute("SELECT session_id FROM telegram_chats WHERE chat_id = ?", (chat_id,)).fetchone()
        if row and not new:
            return row[0]
        sid = "sess_" + uuid.uuid4().hex[:12]
        now = time.time()
        persona = channel or cfg.get("persona_id") or primary_bot_id()
        c.execute("INSERT INTO sessions (session_id, local_session_id, title, instructions, created_at, persona_id) VALUES (?, NULL, ?, ?, ?, ?)",
                  (sid, ("Telegram：" + title_hint)[:80], cfg.get("instructions") or TELEGRAM_DEFAULT_INSTRUCTIONS, now, persona))
        if channel:
            c.execute("INSERT INTO telegram_bot_chats (channel, chat_id, session_id, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT(channel, chat_id) DO UPDATE SET session_id = excluded.session_id, updated_at = excluded.updated_at",
                      (channel, chat_id, sid, now))
        else:
            c.execute("INSERT INTO telegram_chats (chat_id, session_id, updated_at) VALUES (?, ?, ?) ON CONFLICT(chat_id) DO UPDATE SET session_id = excluded.session_id, updated_at = excluded.updated_at",
                      (chat_id, sid, now))
        conn.commit()
        return sid
    finally:
        conn.close()

def _active_task_for_session(sid):
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT task_id, status FROM tasks WHERE session_id = ? AND status IN ('running', 'waiting_user') ORDER BY created_at DESC LIMIT 1", (sid,)).fetchone()
        return row
    finally:
        conn.close()

def telegram_chat_for_task(task_id):
    conn = get_db_connection()
    try:
        row = conn.execute("SELECT chat_id FROM telegram_tasks WHERE task_id = ?", (task_id,)).fetchone()
        return row[0] if row else None
    finally:
        conn.close()

def _telegram_safe_send(cfg, chat_id, text, reply_markup=None):
    try:
        cloud_telegram.send_text(cfg, chat_id, text, reply_markup)
        return True
    except cloud_telegram.TelegramAPIError as e:
        _tg_status(cfg.get("_channel") or "")["last_error"] = str(e)
        return False

def telegram_start_task(cfg, chat_id, sid, text):
    bot = get_persona(cfg.get("_channel")) if cfg.get("_channel") else None
    if bot and bot.get("model") and bot.get("credential"):
        # Bot 自己选了模型：它的 Telegram 渠道也跟着用（思考深度由 session 所属 Bot 决定）
        cfg = dict(cfg, model=bot["model"], credential=bot["credential"])
    provider, p_status, p_err = resolve_provider({"credential": cfg["credential"]})
    if p_err:
        _telegram_safe_send(cfg, chat_id, f"云端凭据不可用（{p_status}）：{p_err}")
        return None
    instructions = cfg.get("instructions") or TELEGRAM_DEFAULT_INSTRUCTIONS
    tid = "task_" + uuid.uuid4().hex[:12]
    now = time.time()
    conn = get_db_connection()
    try:
        c = conn.cursor()
        c.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'user', ?, ?)", (sid, text, now))
        c.execute("INSERT INTO tasks (task_id, session_id, client_nonce, status, model, created_at) VALUES (?, ?, NULL, 'running', ?, ?)",
                  (tid, sid, cfg["model"], now))
        c.execute("INSERT INTO telegram_tasks (task_id, chat_id, created_at, channel) VALUES (?, ?, ?, ?)", (tid, chat_id, now, cfg.get("_channel") or ""))
        conn.commit()
    finally:
        conn.close()
    with active_tasks_lock:
        active_tasks[tid] = {"process": None, "cancelled": False, "pid": None}
    try:
        cloud_telegram.call(cfg, "sendChatAction", {"chat_id": chat_id, "action": "typing"}, timeout=10)
    except cloud_telegram.TelegramAPIError:
        pass

    def worker():
        try:
            run_agent_task(tid, sid, text, cfg["model"], provider, instructions)
        finally:
            conn2 = get_db_connection()
            try:
                status = (conn2.execute("SELECT status FROM tasks WHERE task_id = ?", (tid,)).fetchone() or ["failed"])[0]
                last = conn2.execute("SELECT content FROM messages WHERE session_id = ? AND role = 'assistant' AND content IS NOT NULL AND timestamp >= ? ORDER BY id DESC LIMIT 1",
                                     (sid, now)).fetchone()
                err = conn2.execute("SELECT payload FROM task_events WHERE task_id = ? AND event_type = 'error' ORDER BY id DESC LIMIT 1", (tid,)).fetchone()
            finally:
                conn2.close()
            if status == "completed":
                reply = (last[0] if last else "") or "（完成，无文字回复）"
            elif status == "cancelled":
                reply = "任务已停止。"
            else:
                detail = ""
                if err:
                    try: detail = json.loads(err[0]).get("error", "")
                    except Exception: detail = ""
                reply = f"任务结束（{status}）。{detail}".strip()
                if last and last[0]:
                    reply += "\n\n" + last[0]
            _telegram_safe_send(cfg, chat_id, reply)

    threading.Thread(target=worker, daemon=True, name="telegram-task").start()
    return tid

def telegram_handle_message(cfg, msg):
    chat = msg.get("chat") or {}
    chat_id = chat.get("id")
    if not isinstance(chat_id, int):
        return
    if chat_id not in cfg.get("allowed_chat_ids", []):
        if (cfg.get("_channel") or "", chat_id) not in _telegram_warned_chats:
            _telegram_warned_chats.add((cfg.get("_channel") or "", chat_id))
            _telegram_safe_send(cfg, chat_id, f"这个会话尚未授权。chat id：{chat_id}\n请在 OpenMinis 云电脑设置 → Telegram 中把它加入允许列表。")
        return
    text = (msg.get("text") or msg.get("caption") or "").strip()
    if not text:
        _telegram_safe_send(cfg, chat_id, "目前只支持文字消息。")
        return
    title_hint = chat.get("title") or chat.get("username") or chat.get("first_name") or str(chat_id)
    command = text.split()[0].split("@")[0].lower() if text.startswith("/") else None
    if command in ("/start", "/help"):
        _telegram_safe_send(cfg, chat_id, TELEGRAM_HELP)
        return
    sid = telegram_session_for(cfg, chat_id, title_hint, new=(command == "/new"))
    active = _active_task_for_session(sid)
    if command == "/new":
        _telegram_safe_send(cfg, chat_id, "已开始新会话。")
        return
    if command == "/stop":
        if active:
            with active_tasks_lock:
                if active[0] in active_tasks:
                    active_tasks[active[0]]["cancelled"] = True
            _telegram_safe_send(cfg, chat_id, "正在停止当前任务…")
        else:
            _telegram_safe_send(cfg, chat_id, "当前没有运行中的任务。")
        return
    if command == "/status":
        _telegram_safe_send(cfg, chat_id, f"当前任务：{active[1]}" if active else "当前没有运行中的任务。")
        return
    if active:
        _telegram_safe_send(cfg, chat_id, "上一个任务还在运行（" + ("等待审批" if active[1] == "waiting_user" else "运行中") + "），完成后再发，或发送 /stop 停止。")
        return
    telegram_start_task(cfg, chat_id, sid, text)

def telegram_handle_callback(cfg, cq):
    data = cq.get("data") or ""
    chat_id = ((cq.get("message") or {}).get("chat") or {}).get("id")
    answer = "无效操作"
    if chat_id in cfg.get("allowed_chat_ids", []) and re.match(r"^ap:(appr_[a-f0-9]{12}):(y|n)$", data):
        _, aid, yn = data.split(":")
        conn = get_db_connection()
        try:
            row = conn.execute("SELECT task_id FROM approvals WHERE approval_id = ?", (aid,)).fetchone()
        finally:
            conn.close()
        if row and telegram_chat_for_task(row[0]) == chat_id and telegram_channel_for_task(row[0]) == (cfg.get("_channel") or ""):
            code, body = resolve_approval(row[0], aid, "approved" if yn == "y" else "denied", "via Telegram")
            answer = ("已批准" if yn == "y" else "已拒绝") if code == 200 else "该审批已处理或已过期"
    try:
        cloud_telegram.call(cfg, "answerCallbackQuery", {"callback_query_id": cq.get("id"), "text": answer}, timeout=10)
    except cloud_telegram.TelegramAPIError:
        pass
    if answer in ("已批准", "已拒绝"):
        _telegram_safe_send(cfg, chat_id, answer + "。")

def telegram_notify_approval(task_id, approval):
    chat_id = telegram_chat_for_task(task_id)
    if chat_id is None:
        return False
    cfg = telegram_config(telegram_channel_for_task(task_id) or "")
    if not cfg:
        return False
    args = json.dumps(approval.get("arguments"), ensure_ascii=False)
    text = f"⚠️ 需要你的审批：{approval.get('reason')}\n工具：{approval.get('tool')}\n参数：{args[:800]}"
    markup = {"inline_keyboard": [[{"text": "批准", "callback_data": f"ap:{approval['approval_id']}:y"},
                                   {"text": "拒绝", "callback_data": f"ap:{approval['approval_id']}:n"}]]}
    return _telegram_safe_send(cfg, chat_id, text, markup)

def telegram_poll_once(cfg):
    channel = cfg.get("_channel") or ""
    key = "offset" + (":" + channel if channel else "")
    offset = int(_telegram_state(key) or 0)
    updates = cloud_telegram.call(cfg, "getUpdates", {"offset": offset, "timeout": TELEGRAM_POLL_TIMEOUT,
                                                      "allowed_updates": ["message", "callback_query"]},
                                  timeout=TELEGRAM_POLL_TIMEOUT + 15)
    st = _tg_status(channel)
    st["last_poll_at"] = time.time()
    for u in updates or []:
        uid = u.get("update_id")
        if isinstance(uid, int):
            _telegram_state(key, uid + 1)
        try:
            if "message" in u:
                telegram_handle_message(cfg, u["message"])
            elif "callback_query" in u:
                telegram_handle_callback(cfg, u["callback_query"])
            st["handled"] += 1
        except Exception as e:
            st["last_error"] = "handler: " + type(e).__name__
    return len(updates or [])

def _telegram_main(channel=""):
    st = _tg_status(channel)
    st["running"] = True
    try:
        while not _telegram_stop.is_set():
            cfg = telegram_config(channel)
            if not cfg or not cfg.get("enabled", True):
                if channel:
                    return  # Bot 专属渠道已删除：结束线程
                _telegram_stop.wait(5)
                continue
            try:
                telegram_poll_once(cfg)
                st["last_error"] = None
            except cloud_telegram.TelegramAPIError as e:
                st["last_error"] = str(e)
                _telegram_stop.wait(5)
            except Exception as e:
                st["last_error"] = type(e).__name__
                _telegram_stop.wait(5)
    finally:
        st["running"] = False

def telegram_running(channel=""):
    t = _telegram_threads.get(channel)
    return bool(t and t.is_alive())

def start_telegram(channel=None):
    """channel 为 None 时启动共享渠道与全部 Bot 专属渠道。"""
    channels = [""] + telegram_bot_channels() if channel is None else [channel]
    _telegram_stop.clear()
    for ch in channels:
        if telegram_running(ch):
            continue
        t = threading.Thread(target=_telegram_main, args=(ch,), name="telegram-poller" + (":" + ch if ch else ""), daemon=True)
        _telegram_threads[ch] = t
        t.start()

def stop_telegram():
    _telegram_stop.set()
    for t in list(_telegram_threads.values()):
        t.join(timeout=TELEGRAM_POLL_TIMEOUT + 20)

def telegram_save(channel, req_json):
    """保存共享或 Bot 专属 Telegram 配置，返回 (状态码, 响应体)。"""
    body = req_json.get("config", req_json)
    existing = telegram_config(channel)
    if isinstance(body, dict) and existing and not body.get("bot_token"):
        body = dict(body, bot_token=existing["bot_token"])  # 只改允许列表等字段时沿用已存 Token
    if isinstance(body, dict) and existing and "proxy" not in body and existing.get("proxy"):
        body = dict(body, proxy=existing["proxy"])  # 未提交 proxy 字段时沿用；提交空字符串表示清除
    try:
        cfg = cloud_telegram.validate(body, lambda n: bool(CREDENTIAL_NAME_RE.match(n)) and any(c["name"] == n for c in list_credentials()))
        if channel:
            cfg["persona_id"] = channel
        else:
            try:
                cfg["persona_id"] = validate_persona_ref(body.get("persona_id"))
            except ValueError as e:
                raise cloud_telegram.TelegramConfigError(str(e))
        for other in [""] + telegram_bot_channels():
            if other == channel:
                continue
            oc = telegram_config(other)
            if oc and oc.get("bot_token") == cfg["bot_token"]:
                raise cloud_telegram.TelegramConfigError("这个 Bot Token 已被另一个渠道使用（同一 Token 不能同时长轮询）")
        me = cloud_telegram.call(cfg, "getMe", timeout=15)
        cfg["bot_username"] = (me or {}).get("username")
    except cloud_telegram.TelegramConfigError as e:
        return 400, {"error": str(e)}
    except cloud_telegram.TelegramAPIError as e:
        if e.kind == "unauthorized":
            return 400, {"error": "Bot Token 无效（Telegram 返回 401 Unauthorized）：请在 @BotFather 重新复制完整 Token", "error_kind": "unauthorized"}
        if e.kind == "network":
            via = "代理" if cfg.get("proxy") else ("自定义 API 地址" if cfg.get("api_base") != "https://api.telegram.org" else "api.telegram.org")
            hint = ("请检查代理地址与端口是否可用" if cfg.get("proxy")
                    else "云电脑可能无法直连 Telegram（例如中国大陆的 VPS）：请在 Telegram 设置里填写代理（http / https / socks5）或自建 Bot API 地址后重试")
            return 502, {"error": f"云电脑连不上 Telegram（经 {via}：{e}）。{hint}", "error_kind": "network"}
        return 502, {"error": "Telegram 校验失败：" + str(e), "error_kind": "other"}
    conn = get_db_connection()
    try:
        cloud_notify.save_setting(conn, telegram_setting_name(channel), cfg)
    except cloud_secrets.SecretStoreUnavailable as e:
        return 503, {"error": f"Encrypted store unavailable: {e}"}
    finally:
        conn.close()
    _telegram_warned_chats.clear()
    start_telegram(channel)
    return 200, {"configured": True, "config": cloud_telegram.masked(cfg)}

def telegram_delete(channel):
    conn = get_db_connection()
    try:
        existed = cloud_notify.delete_setting(conn, telegram_setting_name(channel))
        if channel:
            conn.execute("DELETE FROM telegram_state WHERE key = ?", ("offset:" + channel,))
            conn.execute("DELETE FROM telegram_bot_chats WHERE channel = ?", (channel,))
        else:
            conn.execute("DELETE FROM telegram_state WHERE key = 'offset'")
        conn.commit()
    finally:
        conn.close()
    return {"configured": False, "deleted": existed}

def telegram_view(channel):
    cfg = telegram_config(channel)
    if cfg:
        cfg = {k: v for k, v in cfg.items() if k != "_channel"}
    return {"configured": cfg is not None, "config": cloud_telegram.masked(cfg), "channel": channel or "shared",
            "status": dict(_tg_status(channel), running=telegram_running(channel))}

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        query_params = parse_qs(parsed_url.query)

        if path == "/health":
            self._send(200, {
                "status": "ok",
                "service": "openminis-cloud-agent",
                "mode": "cloud-computer",
                "version": "2.0.0",
                "capabilities": {
                    "shell": True,
                    "files": True,
                    "browser": cloud_browser.is_browser_available(),
                    "desktop": cloud_desktop.is_desktop_available(),
                    "display": os.environ.get("DISPLAY", ":99"),
                    "vnc_port": 5901,
                    "novnc_port": 18766,
                    "credential_store": cloud_secrets.status()[0],
                    "approvals": True,
                    "routines": True,
                    "memory_search": True,
                    "skills_lazy_load": True,
                    "notify": True,
                    "pages": True,
                    "subagents": True,
                    "image_generate": True,
                    "telegram": True,
                    "personas": True,
                    "bots": True,
                    "delegation": True,
                    "group_chat": True,
                    "plugins": True
                },
                "timestamp": time.time()
            })
            return

        # Attachment download endpoint with path security & Bearer auth
        if "/attachments/" in path:
            auth = self.headers.get("Authorization", "")
            if not auth.startswith("Bearer ") or auth[7:].strip() != SERVER_TOKEN:
                self._send(401, {"error": "Unauthorized"})
                return
            
            parts = path.split("/")
            # Expected format: /v1/sessions/{sid}/attachments/{filename} or similar
            try:
                s_idx = parts.index("sessions")
                sid = parts[s_idx + 1]
                filename = parts[-1]
            except (ValueError, IndexError):
                self._send(400, {"error": "Invalid attachment path"})
                return

            target, err = safe_path_resolve(sid, os.path.join("attachments", filename))
            if err or not os.path.exists(target) or not os.path.isfile(target):
                self._send(404, {"error": "Attachment not found"})
                return

            try:
                content_type, _ = mimetypes.guess_type(target)
                content_type = content_type or "application/octet-stream"
                with open(target, "rb") as f:
                    file_bytes = f.read()
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(file_bytes)))
                self.end_headers()
                self.wfile.write(file_bytes)
                return
            except Exception as e:
                self._send(500, {"error": str(e)})
                return

        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Bearer ") or auth[7:].strip() != SERVER_TOKEN:
            self._send(401, {"error": "Unauthorized"})
            return

        if path == "/v1/personas":
            self._send(200, {"personas": list_personas()})
            return

        if path == "/v1/settings":
            conn = get_db_connection()
            try:
                rows = dict(conn.execute("SELECT name, value FROM app_settings").fetchall())
            finally:
                conn.close()
            self._send(200, {"timezone": rows.get("timezone"), "server_time": time.time(),
                             "server_local_time": time.strftime("%Y-%m-%d %H:%M:%S")})
            return

        if path == "/v1/plugins":
            installed = PLUGINS.list()
            ids = {p["plugin_id"] for p in installed}
            cat = [dict(c, installed=c["id"] in ids) for c in cloud_plugins.catalog()]
            self._send(200, {"installed": installed, "catalog": cat})
            return

        if path == "/v1/plugins/deps":
            self._send(200, {"tools": cloud_deps.status()})
            return

        if path.startswith("/v1/plugins/") and path.endswith("/tools"):
            pid = path[len("/v1/plugins/"):-len("/tools")]
            if not PLUGINS.get(pid):
                self._send(404, {"error": "Plugin not found"})
                return
            try:
                tools = PLUGINS.list_tools(pid, refresh=True)
            except cloud_mcp.MCPAuthRequired as e:
                self._send(409, {"error": "needs_auth", "message": str(e), "plugin": PLUGINS.get(pid)})
                return
            except (cloud_mcp.MCPError, cloud_plugins.PluginError) as e:
                self._send(502, {"error": str(e), "plugin": PLUGINS.get(pid)})
                return
            self._send(200, {"plugin_id": pid, "tools": [{"name": t["name"], "description": t.get("description", "")} for t in tools]})
            return

        if path.startswith("/v1/plugins/"):
            p = PLUGINS.get(path[len("/v1/plugins/"):])
            if p:
                self._send(200, p)
            else:
                self._send(404, {"error": "Plugin not found"})
            return

        if path == "/v1/bots":
            self._send(200, {"bots": [bot_detail(b) for b in list_personas()], "primary": primary_bot_id()})
            return

        if path.startswith("/v1/bots/") and path.endswith("/telegram"):
            bid = path[len("/v1/bots/"):-len("/telegram")]
            if not get_persona(bid):
                self._send(404, {"error": "Bot not found"})
                return
            self._send(200, telegram_view(bid))
            return

        if path.startswith("/v1/bots/") and path.endswith("/library"):
            bid = path[len("/v1/bots/"):-len("/library")]
            if not get_persona(bid):
                self._send(404, {"error": "Bot not found"})
                return
            self._send(200, {"items": bot_library(bid)})
            return

        m_media = re.match(r"^/v1/bots/([a-z0-9][a-z0-9_-]{0,31})/library/media/(\d+)/(\d+)$", path)
        if m_media:
            url = library_media(m_media.group(1), int(m_media.group(2)), int(m_media.group(3)))
            if not url:
                self._send(404, {"error": "Media not found"})
                return
            self._send(200, {"url": url})
            return

        if path == "/v1/desktop/status":
            conn = get_db_connection()
            try:
                running = conn.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('running', 'queued')").fetchone()[0]
            finally:
                conn.close()
            self._send(200, {"available": cloud_desktop.is_desktop_available(), "busy": running > 0, "running_tasks": running,
                             "token_proxy": cloud_displays.token_proxy_enabled(), "displays": DISPLAYS.list()})
            return

        if path == "/v1/resources":
            specs = iso.server_specs(GLOBAL_WORKSPACE)
            self._send(200, {"settings": resource_settings(), "defaults": iso.DEFAULTS, "specs": specs,
                             "recommended": iso.recommend(specs), "usage": resource_usage(),
                             "per_bot_display": cloud_displays.DisplayManager.available()})
            return

        if path == "/v1/queue":
            self._send(200, GATE.status())
            return

        if path == "/v1/groups":
            conn = get_db_connection()
            try:
                groups = cloud_groups.list_groups(conn)
            finally:
                conn.close()
            for g in groups:
                g["typing"] = GROUPS.typing_list(g["group_id"])
            self._send(200, {"groups": groups})
            return

        m_grp = re.match(r"^/v1/groups/(grp_[a-f0-9]{10})(/messages)?$", path)
        if m_grp:
            gid = m_grp.group(1)
            conn = get_db_connection()
            try:
                g = cloud_groups.get_group(conn, gid)
                if not g:
                    self._send(404, {"error": "Group not found"})
                    return
                if not m_grp.group(2):
                    payload = group_payload(conn, g, 0)
                    self._send(200, payload)
                    return
            finally:
                conn.close()
            try:
                after = int((query_params.get("after") or ["0"])[0])
                wait = float((query_params.get("wait") or ["0"])[0])
            except ValueError:
                self._send(400, {"error": "after / wait 必须是数字"})
                return
            msgs, typing = GROUPS.wait_for(gid, after, wait) if wait > 0 else (None, GROUPS.typing_list(gid))
            if msgs is None:
                conn = get_db_connection()
                try:
                    msgs = cloud_groups.messages_after(conn, gid, after)
                finally:
                    conn.close()
            self._send(200, {"messages": msgs, "typing": typing})
            return

        if path == "/v1/delegations":
            sid = (query_params.get("session_id") or [None])[0]
            items = list_delegations(sid)
            for it in items:
                for k in ("from_bot", "to_bot"):
                    it[k.replace("bot", "name")] = _bot_label(get_persona(it[k])) if it[k] else "主助手"
            self._send(200, {"delegations": items})
            return

        if path.startswith("/v1/bots/") and path.endswith("/export"):
            bid = path[len("/v1/bots/"):-len("/export")]
            if not get_persona(bid):
                self._send(404, {"error": "Bot not found"})
                return
            routines = [r for r in list_routines() if r.get("persona_id") == bid]
            conn = get_db_connection()
            try:
                mem = [e for e in cloud_memory.list_entries(conn, limit=2000) if e.get("persona") == bid]
                bundle = cloud_bots.export_bundle(conn, bid, routines, mem)
            finally:
                conn.close()
            self._send(200, bundle)
            return

        if path.startswith("/v1/bots/"):
            b = get_persona(path[len("/v1/bots/"):])
            if b:
                self._send(200, bot_detail(b))
            else:
                self._send(404, {"error": "Bot not found"})
            return

        if path.startswith("/v1/personas/"):
            p = get_persona(path[len("/v1/personas/"):])
            if p:
                self._send(200, p)
            else:
                self._send(404, {"error": "Persona not found"})
            return

        if path == "/v1/telegram":
            self._send(200, telegram_view(""))
            return


        if path == "/v1/pages":
            conn = get_db_connection()
            try:
                self._send(200, {"pages": cloud_pages.list_pages(conn)})
            finally:
                conn.close()
            return

        if path.startswith("/v1/pages/"):
            rest = path[len("/v1/pages/"):]
            pid, _, fmt = rest.partition("/")
            conn = get_db_connection()
            try:
                page = cloud_pages.get(conn, pid) if cloud_pages.PAGE_ID_RE.match(pid) else None
            finally:
                conn.close()
            if not page or fmt not in ("", "html"):
                self._send(404, {"error": "Page not found"})
                return
            if fmt == "html":
                body = page["html"].encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Security-Policy", "sandbox allow-scripts; default-src 'none'; img-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            self._send(200, page)
            return

        if path == "/v1/notify":
            available, reason = cloud_secrets.status()
            conn = get_db_connection()
            try:
                cfg = cloud_notify.load(conn) if available else None
                err = None
            except Exception as e:
                cfg, err = None, type(e).__name__
            finally:
                conn.close()
            self._send(200, {"available": available, "reason": reason or err, "configured": cfg is not None,
                             "config": cloud_notify.masked(cfg), "last": cloud_notify.last_status()})
            return

        if path == "/v1/skills":
            conn = get_db_connection()
            try:
                self._send(200, {"skills": cloud_skills.list_index(conn)})
            finally:
                conn.close()
            return

        if path.startswith("/v1/skills/"):
            name = unquote(path[len("/v1/skills/"):])
            conn = get_db_connection()
            try:
                skill = cloud_skills.load(conn, name)
            finally:
                conn.close()
            if skill:
                self._send(200, skill)
            else:
                self._send(404, {"error": "Skill not found"})
            return

        if path == "/v1/memory":
            def qp(name, default=None):
                v = query_params.get(name)
                return v[0] if v else default
            conn = get_db_connection()
            try:
                if qp("query") is not None or qp("category") or qp("persona") is not None:
                    entries = cloud_memory.search(conn, qp("query", ""), qp("category"), int(qp("limit", "20")), source=qp("source"), persona=qp("persona"))
                else:
                    since = qp("since")
                    entries = cloud_memory.list_entries(conn, since=float(since) if since else None, source=qp("source"), limit=int(qp("limit", "200")))
                fts = cloud_memory.fts_enabled(conn)
            except ValueError as e:
                self._send(400, {"error": str(e)})
                return
            finally:
                conn.close()
            self._send(200, {"entries": entries, "fts": fts, "server_time": time.time()})
            return

        if path == "/v1/credentials":
            available, reason = cloud_secrets.status()
            self._send(200, {"available": available, "reason": reason, "credentials": list_credentials()})
            return

        if path == "/v1/sessions":
            conn = get_db_connection()
            c = conn.cursor()
            bot_filter = (query_params.get("bot") or [None])[0]
            if bot_filter:
                c.execute("SELECT session_id, local_session_id, title, created_at, persona_id FROM sessions WHERE persona_id = ? ORDER BY created_at DESC", (bot_filter,))
            else:
                c.execute("SELECT session_id, local_session_id, title, created_at, persona_id FROM sessions ORDER BY created_at DESC")
            sessions = [{"session_id": r[0], "local_session_id": r[1], "title": r[2], "created_at": r[3], "persona_id": r[4]} for r in c.fetchall()]
            conn.close()
            self._send(200, {"sessions": sessions})
            return

        if path.startswith("/v1/sessions/") and not path.endswith("/events"):
            sid = path[len("/v1/sessions/"):]
            if "/" in sid:
                # Might be sub-resource
                pass
            else:
                conn = get_db_connection()
                c = conn.cursor()
                c.execute("SELECT session_id, local_session_id, title, instructions, created_at FROM sessions WHERE session_id = ?", (sid,))
                s = c.fetchone()
                if not s:
                    conn.close()
                    self._send(404, {"error": "Session not found"})
                    return
                c.execute("SELECT role, content, tool_calls, tool_call_id, timestamp FROM messages WHERE session_id = ? ORDER BY id ASC", (sid,))
                msgs = []
                for mr in c.fetchall():
                    m = {"role": mr[0], "content": mr[1], "timestamp": mr[4]}
                    if mr[2]:
                        try: m["tool_calls"] = json.loads(mr[2])
                        except: pass
                    if mr[3]:
                        m["tool_call_id"] = mr[3]
                    msgs.append(m)
                c.execute("SELECT task_id, status, model, created_at FROM tasks WHERE session_id = ? ORDER BY created_at DESC", (sid,))
                tasks = [{"task_id": tr[0], "status": tr[1], "model": tr[2], "created_at": tr[3]} for tr in c.fetchall()]
                conn.close()
                self._send(200, {"session_id": s[0], "local_session_id": s[1], "title": s[2], "instructions": s[3], "created_at": s[4], "messages": msgs, "tasks": tasks})
                return

        if path == "/v1/routines":
            bot_filter = (query_params.get("bot") or [None])[0]
            routines = [r for r in list_routines() if not bot_filter or r.get("persona_id") == bot_filter]
            self._send(200, {"routines": routines, "server_time": time.time()})
            return

        if path.startswith("/v1/routines/"):
            parts = path.split("/")
            rid = parts[3] if len(parts) >= 4 else ""
            routine = get_routine(rid) if ROUTINE_ID_RE.match(rid) else None
            if not routine:
                self._send(404, {"error": "Routine not found"})
                return
            if len(parts) == 4:
                routine["runs"] = list_routine_runs(rid)
                self._send(200, routine)
                return
            if len(parts) == 5 and parts[4] == "runs":
                self._send(200, {"routine_id": rid, "runs": list_routine_runs(rid, 100)})
                return
            self._send(404, {"error": "Not found"})
            return

        if path == "/v1/approval-policy":
            self._send(200, {"policy": current_approval_policy(), "default": cloud_policy.DEFAULT_POLICY,
                             "customized": os.path.exists(approval_policy_path())})
            return

        if path.startswith("/v1/tasks/") and path.endswith("/approvals"):
            parts = path.split("/")
            tid = parts[3] if len(parts) == 5 else ""
            conn = get_db_connection()
            c = conn.cursor()
            c.execute("SELECT status FROM tasks WHERE task_id = ?", (tid,))
            t = c.fetchone()
            conn.close()
            if not t:
                self._send(404, {"error": "Task not found"})
                return
            self._send(200, {"task_id": tid, "status": t[0], "approvals": list_approvals(tid)})
            return

        if path.startswith("/v1/tasks/") and path.endswith("/events"):
            # /v1/tasks/{id}/events?after=...
            parts = path.split("/")
            tid = parts[3] if len(parts) >= 4 else ""
            raw_after = query_params.get("after", ["0"])[0]
            try:
                after_cursor = int(raw_after)
            except ValueError:
                self._send(400, {"error": "Invalid after cursor: must be an integer"})
                return

            conn = get_db_connection()
            c = conn.cursor()
            c.execute("SELECT task_id, session_id, status, model, created_at FROM tasks WHERE task_id = ?", (tid,))
            t = c.fetchone()
            if not t:
                conn.close()
                self._send(404, {"error": "Task not found"})
                return
            
            c.execute("SELECT id, event_type, payload, timestamp FROM task_events WHERE task_id = ? AND id > ? ORDER BY id ASC", (tid, after_cursor))
            events = []
            max_id = after_cursor
            for er in c.fetchall():
                eid, etype, payload_str, etime = er
                max_id = max(max_id, eid)
                try: pl = json.loads(payload_str)
                except: pl = {"raw": payload_str}
                events.append({"monotonic_id": eid, "id": eid, "type": etype, "payload": pl, "timestamp": etime})
            conn.close()
            self._send(200, {
                "task_id": t[0],
                "session_id": t[1],
                "status": t[2],
                "model": t[3],
                "created_at": t[4],
                "last_cursor": max_id,
                "events": events
            })
            return

        if path.startswith("/v1/tasks/"):
            tid = path[len("/v1/tasks/"):]
            conn = get_db_connection()
            c = conn.cursor()
            c.execute("SELECT task_id, session_id, status, model, created_at FROM tasks WHERE task_id = ?", (tid,))
            t = c.fetchone()
            if not t:
                conn.close()
                self._send(404, {"error": "Task not found"})
                return
            c.execute("SELECT id, event_type, payload, timestamp FROM task_events WHERE task_id = ? ORDER BY id ASC", (tid,))
            events = []
            max_id = 0
            for er in c.fetchall():
                eid, etype, payload_str, etime = er
                max_id = max(max_id, eid)
                try: pl = json.loads(payload_str)
                except: pl = {"raw": payload_str}
                events.append({"monotonic_id": eid, "id": eid, "type": etype, "payload": pl, "timestamp": etime})
            conn.close()
            self._send(200, {
                "task_id": t[0],
                "session_id": t[1],
                "status": t[2],
                "model": t[3],
                "created_at": t[4],
                "last_cursor": max_id,
                "events": events
            })
            return

        self._send(404, {"error": "Not found"})

    def _authorized(self):
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Bearer ") or auth[7:].strip() != SERVER_TOKEN:
            self._send(401, {"error": "Unauthorized"})
            return False
        return True

    def _read_json_body(self):
        """返回 dict；出错时已发送错误响应并返回 None。"""
        raw_len = self.headers.get("Content-Length", 0)
        try:
            length = int(raw_len)
        except Exception:
            self._send(400, {"error": "Invalid Content-Length"})
            return None

        # 附件上传（base64）放宽到 36MB，其余接口仍限制 5MB
        limit = 36 * 1024 * 1024 if re.match(r"^/v1/sessions/[A-Za-z0-9_-]{1,64}/upload$", urlparse(self.path).path) else 5 * 1024 * 1024
        if length < 0 or length > limit:
            self._send(400 if length < 0 else 413, {"error": "Invalid body size or exceeds limit"})
            return None

        req_json = {}
        if length > 0:
            try:
                body_bytes = self.rfile.read(length)
                req_json = json.loads(body_bytes.decode("utf-8"))
            except Exception:
                self._send(400, {"error": "Invalid JSON body"})
                return None

        if not isinstance(req_json, dict):
            self._send(400, {"error": "Request body must be a JSON object"})
            return None
        return req_json

    def do_PUT(self):
        path = self.path.split("?")[0]
        if not self._authorized():
            return
        req_json = self._read_json_body()
        if req_json is None:
            return

        if path.startswith("/v1/bots/") and path.endswith("/notify"):
            bid = path[len("/v1/bots/"):-len("/notify")]
            if not get_persona(bid):
                self._send(404, {"error": "Bot not found"})
                return
            if not isinstance(req_json.get("enabled"), bool):
                self._send(400, {"error": "enabled must be a boolean"})
                return
            set_bot_notify(bid, req_json["enabled"])
            self._send(200, {"bot_id": bid, "notify": req_json["enabled"]})
            return

        m_grp = re.match(r"^/v1/groups/(grp_[a-f0-9]{10})$", path)
        if m_grp:
            conn = get_db_connection()
            try:
                if not cloud_groups.get_group(conn, m_grp.group(1)):
                    self._send(404, {"error": "Group not found"})
                    return
                try:
                    fields = cloud_groups.validate_fields(req_json, lambda b: bool(get_persona(b)), partial=True)
                except cloud_groups.GroupError as e:
                    self._send(400, {"error": str(e)})
                    return
                g = cloud_groups.update_group(conn, m_grp.group(1), fields)
                self._send(200, group_payload(conn, g, None))
            finally:
                conn.close()
            return

        if path == "/v1/resources":
            try:
                new = update_resource_settings(req_json)
            except iso.SettingsError as e:
                self._send(400, {"error": str(e)})
                return
            self._send(200, {"settings": new, "usage": resource_usage()})
            return

        if path == "/v1/settings":
            tz = req_json.get("timezone")
            if tz is not None and (not isinstance(tz, str) or not re.match(r"^[A-Za-z0-9_+\-]+(/[A-Za-z0-9_+\-]+){0,2}$", tz)):
                self._send(400, {"error": "timezone must be an IANA name such as Asia/Shanghai"})
                return
            try:
                cloud_memory.set_timezone(tz)
            except Exception as e:
                self._send(400, {"error": f"unknown timezone: {tz}"})
                return
            conn = get_db_connection()
            try:
                if tz:
                    conn.execute("INSERT INTO app_settings (name, value) VALUES ('timezone', ?) ON CONFLICT(name) DO UPDATE SET value = excluded.value", (tz,))
                else:
                    conn.execute("DELETE FROM app_settings WHERE name = 'timezone'")
                conn.commit()
            finally:
                conn.close()
            self._send(200, {"timezone": tz})
            return

        if path.startswith("/v1/bots/") and path.endswith("/telegram"):
            bid = path[len("/v1/bots/"):-len("/telegram")]
            if not get_persona(bid):
                self._send(404, {"error": "Bot not found"})
                return
            code, body = telegram_save(bid, req_json)
            self._send(code, body)
            return

        if path.startswith("/v1/plugins/"):
            try:
                p = PLUGINS.update(path[len("/v1/plugins/"):], req_json)
            except cloud_plugins.PluginError as e:
                self._send(400, {"error": str(e)})
                return
            if p:
                self._send(200, p)
            else:
                self._send(404, {"error": "Plugin not found"})
            return

        if path.startswith("/v1/bots/"):
            conn = get_db_connection()
            try:
                bot, created = cloud_bots.upsert(conn, path[len("/v1/bots/"):], req_json, credential_exists)
            except cloud_bots.BotError as e:
                self._send(400, {"error": str(e)})
                return
            finally:
                conn.close()
            self._send(201 if created else 200, bot)
            return

        if path.startswith("/v1/credentials/"):
            name = path[len("/v1/credentials/"):]
            if not CREDENTIAL_NAME_RE.match(name):
                self._send(400, {"error": "Invalid credential name"})
                return
            api_key = req_json.get("api_key")
            if not isinstance(api_key, str) or not api_key.strip() or len(api_key) > 8192:
                self._send(400, {"error": "api_key must be a non-empty string"})
                return
            base_url = req_json.get("base_url", "https://api.openai.com/v1")
            ok, err = validate_base_url(base_url)
            if not ok:
                self._send(400, {"error": err})
                return
            protocol = req_json.get("protocol", "chat")
            if protocol != "chat":
                self._send(400, {"error": "Unsupported provider protocol. Only 'chat' is supported."})
                return
            try:
                created = put_credential(name, api_key.strip(), base_url, protocol)
            except cloud_secrets.SecretStoreUnavailable as e:
                self._send(503, {"error": "Credential store unavailable: " + str(e)})
                return
            self._send(201 if created else 200, {"name": name, "base_url": base_url, "key_hint": credential_hint(api_key.strip()), "stored": True})
            return

        if path.startswith("/v1/personas/"):
            pid = path[len("/v1/personas/"):]
            name = req_json.get("name")
            instructions = req_json.get("instructions")
            emoji = req_json.get("emoji")
            if not PERSONA_ID_RE.match(pid):
                self._send(400, {"error": "persona_id must match ^[a-z0-9][a-z0-9_-]{0,31}$"})
                return
            if not isinstance(name, str) or not name.strip() or len(name) > 60:
                self._send(400, {"error": "name must be a non-empty string (max 60)"})
                return
            if not isinstance(instructions, str) or not instructions.strip() or len(instructions) > 20000:
                self._send(400, {"error": "instructions must be a non-empty string (max 20000)"})
                return
            if emoji is not None and (not isinstance(emoji, str) or len(emoji) > 8):
                self._send(400, {"error": "emoji must be a short string"})
                return
            existed = get_persona(pid) is not None
            now = time.time()
            conn = get_db_connection()
            try:
                conn.execute("INSERT INTO personas (persona_id, name, instructions, emoji, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) "
                             "ON CONFLICT(persona_id) DO UPDATE SET name = excluded.name, instructions = excluded.instructions, emoji = excluded.emoji, updated_at = excluded.updated_at",
                             (pid, name.strip(), instructions, emoji, now, now))
                conn.commit()
            finally:
                conn.close()
            self._send(200 if existed else 201, get_persona(pid))
            return

        if path == "/v1/telegram":
            code, body = telegram_save("", req_json)
            self._send(code, body)
            return

        if path == "/v1/notify":
            conn = get_db_connection()
            try:
                cfg = cloud_notify.save(conn, req_json.get("config", req_json))
            except cloud_notify.NotifyConfigError as e:
                self._send(400, {"error": str(e)})
                return
            except cloud_secrets.SecretStoreUnavailable as e:
                self._send(503, {"error": f"Encrypted store unavailable: {e}"})
                return
            finally:
                conn.close()
            self._send(200, {"configured": True, "config": cloud_notify.masked(cfg)})
            return

        if path.startswith("/v1/routines/"):
            rid = path[len("/v1/routines/"):]
            if not ROUTINE_ID_RE.match(rid) or not get_routine(rid):
                self._send(404, {"error": "Routine not found"})
                return
            try:
                fields = validate_routine_fields(req_json, existing=get_routine(rid))
            except ValueError as e:
                self._send(400, {"error": str(e)})
                return
            self._send(200, update_routine(rid, fields))
            return

        if path == "/v1/approval-policy":
            try:
                saved = cloud_policy.save_policy(approval_policy_path(), req_json.get("policy", req_json))
            except cloud_policy.PolicyError as e:
                self._send(400, {"error": str(e)})
                return
            self._send(200, {"policy": saved, "customized": True})
            return

        self._send(404, {"error": "Not found"})

    def do_DELETE(self):
        path = self.path.split("?")[0]
        query_params = parse_qs(urlparse(self.path).query)
        if not self._authorized():
            return
        if path.startswith("/v1/bots/") and path.endswith("/telegram"):
            self._send(200, telegram_delete(path[len("/v1/bots/"):-len("/telegram")]))
            return
        m_grp = re.match(r"^/v1/groups/(grp_[a-f0-9]{10})$", path)
        if m_grp:
            conn = get_db_connection()
            try:
                ok = cloud_groups.delete_group(conn, m_grp.group(1))
            finally:
                conn.close()
            self._send(200 if ok else 404, {"deleted": True} if ok else {"error": "Group not found"})
            return
        if path.startswith("/v1/bots/"):
            path = "/v1/personas/" + path[len("/v1/bots/"):]
        if path.startswith("/v1/plugins/"):
            if PLUGINS.uninstall(path[len("/v1/plugins/"):]):
                self._send(200, {"deleted": True})
            else:
                self._send(404, {"error": "Plugin not found"})
            return

        if path.startswith("/v1/credentials/"):
            name = path[len("/v1/credentials/"):]
            if not CREDENTIAL_NAME_RE.match(name):
                self._send(400, {"error": "Invalid credential name"})
                return
            if delete_credential(name):
                self._send(200, {"name": name, "deleted": True})
            else:
                self._send(404, {"error": "Credential not found"})
            return

        if path.startswith("/v1/personas/"):
            pid = path[len("/v1/personas/"):]
            conn = get_db_connection()
            try:
                cur = conn.execute("DELETE FROM personas WHERE persona_id = ?", (pid,))
                deleted = cur.rowcount > 0
                purged = 0
                if deleted:
                    conn.execute("UPDATE routines SET persona_id = NULL WHERE persona_id = ?", (pid,))
                    cloud_notify.delete_setting(conn, telegram_setting_name(pid))
                    conn.execute("DELETE FROM telegram_bot_chats WHERE channel = ?", (pid,))
                    if (query_params.get("purge_memory") or ["0"])[0] == "1":
                        purged = conn.execute("DELETE FROM memory_entries WHERE persona = ?", (pid,)).rowcount
                conn.commit()
            finally:
                conn.close()
            if deleted:
                self._send(200, {"persona_id": pid, "deleted": True, "memory_purged": purged})
            else:
                self._send(404, {"error": "Persona not found"})
            return

        if path == "/v1/telegram":
            self._send(200, telegram_delete(""))
            return

        if path.startswith("/v1/pages/"):
            pid = path[len("/v1/pages/"):]
            conn = get_db_connection()
            try:
                ok = bool(cloud_pages.PAGE_ID_RE.match(pid)) and cloud_pages.delete(conn, pid)
            finally:
                conn.close()
            if ok:
                self._send(200, {"page_id": pid, "deleted": True})
            else:
                self._send(404, {"error": "Page not found"})
            return

        if path == "/v1/notify":
            conn = get_db_connection()
            try:
                existed = cloud_notify.delete(conn)
            finally:
                conn.close()
            self._send(200, {"configured": False, "deleted": existed})
            return

        if path.startswith("/v1/skills/"):
            name = unquote(path[len("/v1/skills/"):])
            conn = get_db_connection()
            try:
                ok = cloud_skills.delete(conn, name)
            finally:
                conn.close()
            if ok:
                self._send(200, {"name": name, "deleted": True})
            else:
                self._send(404, {"error": "Skill not found"})
            return

        if path.startswith("/v1/memory/"):
            raw = path[len("/v1/memory/"):]
            conn = get_db_connection()
            try:
                ok = raw.isdigit() and cloud_memory.delete(conn, int(raw))
            finally:
                conn.close()
            if ok:
                self._send(200, {"id": int(raw), "deleted": True})
            else:
                self._send(404, {"error": "Memory entry not found"})
            return

        if path.startswith("/v1/routines/"):
            rid = path[len("/v1/routines/"):]
            if ROUTINE_ID_RE.match(rid) and delete_routine(rid):
                self._send(200, {"routine_id": rid, "deleted": True})
            else:
                self._send(404, {"error": "Routine not found"})
            return

        if path == "/v1/approval-policy":
            cloud_policy.reset_policy(approval_policy_path())
            self._send(200, {"policy": current_approval_policy(), "customized": False})
            return

        self._send(404, {"error": "Not found"})

    def do_POST(self):
        path = self.path.split("?")[0]
        if not self._authorized():
            return
        req_json = self._read_json_body()
        if req_json is None:
            return

        if path == "/v1/groups":
            try:
                fields = cloud_groups.validate_fields(req_json, lambda b: bool(get_persona(b)))
            except cloud_groups.GroupError as e:
                self._send(400, {"error": str(e)})
                return
            conn = get_db_connection()
            try:
                g = cloud_groups.create_group(conn, fields)
                self._send(201, group_payload(conn, g, None))
            finally:
                conn.close()
            return

        m_grp = re.match(r"^/v1/groups/(grp_[a-f0-9]{10})/messages$", path)
        if m_grp:
            gid = m_grp.group(1)
            content = req_json.get("content")
            if not isinstance(content, str) or not content.strip() or len(content) > 8000:
                self._send(400, {"error": "content 必须是 1–8000 字的文字"})
                return
            conn = get_db_connection()
            try:
                if not cloud_groups.get_group(conn, gid):
                    self._send(404, {"error": "Group not found"})
                    return
                provider_req = req_json.get("provider")
                if provider_req:
                    provider, _st, p_err = resolve_provider(provider_req)
                    if not p_err:
                        GROUP_FALLBACK[gid] = (req_json.get("model") or "gpt-4o", provider)
                mid = cloud_groups.add_message(conn, gid, "user", "text", content.strip())
            finally:
                conn.close()
            GROUPS.on_user_message(gid, mid, content.strip(), GROUP_FALLBACK.get(gid))
            GROUPS.notify()
            self._send(202, {"message_id": mid})
            return

        if path == "/v1/plugins/install":
            try:
                if req_json.get("catalog_id"):
                    manifest, source = cloud_plugins.catalog_entry(req_json["catalog_id"]), "catalog"
                    if not manifest:
                        raise cloud_plugins.PluginError("unknown catalog_id")
                elif req_json.get("url"):
                    manifest, source = cloud_plugins.fetch_manifest(req_json["url"]), "url"
                elif isinstance(req_json.get("manifest"), dict):
                    manifest, source = req_json["manifest"], "manifest"
                else:
                    raise cloud_plugins.PluginError("one of catalog_id, url or manifest is required")
                checked = cloud_plugins.validate_manifest(manifest)
                if source != "catalog" and checked["kind"] == "mcp" and checked["mcp"]["transport"] == "stdio" and req_json.get("acknowledge_command") is not True:
                    # 非内置清单会在 VPS 上运行命令：先返回预览，需用户确认后带 acknowledge_command 重试
                    self._send(428, {"error": "confirm_command", "preview": checked,
                                     "command": " ".join([checked["mcp"]["command"]] + checked["mcp"]["args"])})
                    return
                p, created = PLUGINS.install(manifest, source, req_json.get("secrets"), req_json.get("default_grant", True) is not False)
            except cloud_plugins.PluginError as e:
                self._send(400, {"error": str(e)})
                return
            self._send(201 if created else 200, p)
            return

        m_up = re.match(r"^/v1/sessions/([A-Za-z0-9_-]{1,64})/upload$", path)
        if m_up:
            sid = m_up.group(1)
            conn = get_db_connection()
            try:
                found = conn.execute("SELECT 1 FROM sessions WHERE session_id = ?", (sid,)).fetchone()
            finally:
                conn.close()
            if not found:
                self._send(404, {"error": "Session not found"})
                return
            data_b64 = req_json.get("data_base64")
            if not isinstance(data_b64, str) or not data_b64:
                self._send(400, {"error": "data_base64 must be a non-empty string"})
                return
            try:
                import base64
                data = base64.b64decode(data_b64, validate=True)
            except Exception:
                self._send(400, {"error": "data_base64 is not valid base64"})
                return
            if len(data) > 25 * 1024 * 1024:
                self._send(413, {"error": "附件超过 25MB"})
                return
            try:
                self._send(200, save_upload(sid, str(req_json.get("filename") or "file"), data))
            except ValueError as e:
                self._send(400, {"error": str(e)})
            return

        if path == "/v1/desktop/display":
            # 手机「电脑」页：打开某个 Bot 的屏幕（独立模式按需启动），返回 noVNC token
            bid = req_json.get("bot_id")
            proxy = cloud_displays.token_proxy_enabled()
            if bid:
                if not isinstance(bid, str) or not get_persona(bid):
                    self._send(404, {"error": "Bot not found"})
                    return
                if iso.bot_settings(resource_settings(), bid)["browser_profile"] == "per_bot":
                    info = DISPLAYS.ensure(bid)
                    if info:
                        self._send(200, {"token_proxy": proxy, "token": info["token"], "display": info["display"],
                                         "own_display": True, "resolution": info["resolution"]})
                        return
            self._send(200, {"token_proxy": proxy, "token": "main", "display": cloud_displays.MAIN_DISPLAY, "own_display": False})
            return

        if path == "/v1/desktop/input":
            # 手机「电脑」页：把剪贴板文字或键盘输入发到云电脑桌面（与 Agent 共用 desktop_lock）
            action = req_json.get("action")
            if action == "type":
                text = req_json.get("text")
                if not isinstance(text, str) or not text or len(text) > 10000:
                    self._send(400, {"error": "text must be a non-empty string (max 10000)"})
                    return
                args = {"action": "type", "text": text}
            elif action == "key":
                key = req_json.get("key")
                if not isinstance(key, str) or not re.match(r"^[A-Za-z0-9_+]{1,40}$", key):
                    self._send(400, {"error": "key must be an xdotool key name such as Return or ctrl+v"})
                    return
                args = {"action": "key", "key": key}
            else:
                self._send(400, {"error": "action must be type or key"})
                return
            if not cloud_desktop.is_desktop_available():
                self._send(503, {"error": "云电脑桌面未运行：请先安装 / 更新云电脑桌面环境"})
                return
            display = None
            bid = req_json.get("bot_id")
            if isinstance(bid, str) and DISPLAYS.info(bid):
                display = DISPLAYS.info(bid)["display"]
                DISPLAYS.touch(bid)
            res = cloud_desktop.execute_desktop_action("phone", GLOBAL_WORKSPACE, args, display_override=display)
            self._send(200 if not res.get("error") else 500, res)
            return

        if path == "/v1/plugins/deps/install":
            tool = cloud_deps.tool_for(req_json.get("tool") or "") or req_json.get("tool")
            if tool not in cloud_deps.TOOLS:
                self._send(400, {"error": "tool must be one of: node, npx, uv, uvx"})
                return
            info = cloud_deps.TOOLS[tool]
            if req_json.get("confirm") is not True:
                # 会从官方地址下载并在 VPS 上安装可执行文件：必须由用户确认后带 confirm 重试
                self._send(428, {"error": "confirm_install", "tool": tool, "label": info["label"], "source": info["source"],
                                 "install_dir": cloud_deps.bin_dir(),
                                 "message": f"将从 {info['source']} 下载 {info['label']}，校验 SHA-256 后安装到 {cloud_deps.bin_dir()}"})
                return
            job = cloud_deps.start_install(tool)
            self._send(202, {"job": job})
            return

        if path == "/v1/plugins/import-phone":
            servers = req_json.get("servers")
            if not isinstance(servers, list) or len(servers) > 50:
                self._send(400, {"error": "servers must be a list (max 50)"})
                return
            results = []
            for s in servers:
                try:
                    manifest, values = cloud_plugins.phone_manifest(s)
                    p, _ = PLUGINS.install(manifest, "phone", values, default_grant=True)
                    results.append({"id": s.get("id"), "plugin_id": p["plugin_id"], "status": p["status"]})
                except cloud_plugins.PluginError as e:
                    results.append({"id": s.get("id") if isinstance(s, dict) else None, "error": str(e)})
            self._send(200, {"results": results})
            return

        if path == "/v1/bots/import":
            try:
                res = import_bot_bundle(req_json)
            except (cloud_bots.BotError, ValueError) as e:
                self._send(400, {"error": str(e)})
                return
            self._send(201, res)
            return

        if path == "/v1/sessions":
            title = req_json.get("title", "Cloud Session")
            try:
                persona_id = validate_persona_ref(req_json.get("persona_id"))
            except ValueError as e:
                self._send(400, {"error": str(e)})
                return
            sid = "sess_" + uuid.uuid4().hex[:12]
            created_at = time.time()
            conn = get_db_connection()
            c = conn.cursor()
            c.execute("INSERT INTO sessions (session_id, title, created_at, persona_id) VALUES (?, ?, ?, ?)", (sid, title, created_at, persona_id))
            conn.commit()
            conn.close()
            self._send(201, {"session_id": sid, "title": title, "created_at": created_at, "persona_id": persona_id})
            return

        if path == "/v1/sessions/import":
            local_session_id = req_json.get("local_session_id")
            if not isinstance(local_session_id, str) or not local_session_id.strip():
                self._send(400, {"error": "local_session_id must be a non-empty string"})
                return

            title = req_json.get("title", "Imported Session")
            instructions = req_json.get("instructions", "You are OpenMinis Cloud Agent.")
            history = req_json.get("history", [])
            # Support both workspace_files, files and work_context
            workspace_files = req_json.get("workspace_files") or req_json.get("files") or []
            if isinstance(req_json.get("work_context"), dict):
                wc_files = req_json["work_context"].get("files", [])
                if isinstance(wc_files, list):
                    workspace_files.extend(wc_files)
                if not req_json.get("instructions") and req_json["work_context"].get("instructions"):
                    instructions = req_json["work_context"]["instructions"]

            conn = get_db_connection()
            c = conn.cursor()
            c.execute("SELECT session_id, created_at FROM sessions WHERE local_session_id = ?", (local_session_id,))
            existing = c.fetchone()
            
            if existing:
                sid = existing[0]
                created_at = existing[1]
                # Update instructions/title if provided
                c.execute("UPDATE sessions SET title = ?, instructions = ? WHERE session_id = ?", (title, instructions, sid))
                conn.commit()
            else:
                sid = "sess_" + uuid.uuid4().hex[:12]
                created_at = time.time()
                # 手机导入的会话归属指定 Bot，未指定时归主 Bot（没有主 Bot 则为默认）
                import_persona = req_json.get("persona_id") if isinstance(req_json.get("persona_id"), str) and get_persona(req_json.get("persona_id")) else primary_bot_id()
                c.execute("INSERT INTO sessions (session_id, local_session_id, title, instructions, created_at, persona_id) VALUES (?, ?, ?, ?, ?, ?)",
                          (sid, local_session_id, title, instructions, created_at, import_persona))
                
                # Insert history messages if any
                if isinstance(history, list):
                    for hm in history:
                        if isinstance(hm, dict):
                            role = hm.get("role", "user")
                            content = hm.get("content", "")
                            if isinstance(content, list):
                                content = json.dumps(content, ensure_ascii=False)
                            if not isinstance(content, (str, type(None))):
                                continue
                            tc = json.dumps(hm.get("tool_calls")) if hm.get("tool_calls") else None
                            tcid = hm.get("tool_call_id")
                            c.execute("INSERT INTO messages (session_id, role, content, tool_calls, tool_call_id, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
                                      (sid, role, content, tc, tcid, time.time()))
                conn.commit()
            conn.close()

            # Process workspace_files (skills, memory, etc. with size & path safety check)
            imported_files_count = 0
            memory_indexed = 0
            skills_indexed = 0
            if isinstance(workspace_files, list):
                ws = get_session_workspace(sid)
                for wf in workspace_files:
                    if not isinstance(wf, dict): continue
                    fpath = wf.get("path", "")
                    fcontent = wf.get("content", "")
                    if not fpath or not isinstance(fcontent, str): continue
                    if len(fcontent.encode("utf-8")) > 2 * 1024 * 1024: continue # >2MB skip
                    
                    # Security validation against path traversal and symlinks
                    target, err = safe_path_resolve(sid, fpath)
                    if err or not target: continue
                    if os.path.islink(target): continue # reject symlinks
                    
                    try:
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        with open(target, "w", encoding="utf-8") as f:
                            f.write(fcontent)
                        imported_files_count += 1
                    except Exception:
                        pass
                    # 手机记忆文件同时写入全局记忆索引（同一来源文件整体替换）
                    norm = fpath.lstrip("/").replace("\\", "/")
                    skill_parts = norm.split("/")
                    if len(skill_parts) == 3 and skill_parts[0] == "skills" and skill_parts[2] == "SKILL.md":
                        sconn = get_db_connection()
                        try:
                            cloud_skills.upsert(sconn, skill_parts[1], fcontent, source="phone")
                            skills_indexed += 1
                        except Exception as e:
                            print(f"skill import failed for {norm}: {e}")
                        finally:
                            sconn.close()
                    if norm.startswith("memory/") and norm.endswith(".md"):
                        mconn = get_db_connection()
                        try:
                            memory_indexed += cloud_memory.import_file(mconn, norm, fcontent, source="phone")
                        except Exception as e:
                            print(f"memory import failed for {norm}: {e}")
                        finally:
                            mconn.close()

            self._send(200 if existing else 201, {
                "session_id": sid,
                "local_session_id": local_session_id,
                "title": title,
                "status": "ready",
                "imported_messages_count": len(history) if isinstance(history, list) else 0,
                "imported_files_count": imported_files_count,
                "memory_entries_indexed": memory_indexed,
                "skills_indexed": skills_indexed,
                "created_at": created_at
            })
            return

        if path.startswith("/v1/sessions/") and path.endswith("/messages"):
            parts = path.split("/")
            sid = parts[3] if len(parts) >= 4 else ""
            
            content = req_json.get("content")
            if not isinstance(content, str) or not content.strip():
                self._send(400, {"error": "content must be a non-empty string"})
                return

            message_parts = req_json.get("message_parts")
            db_user_content = content
            if message_parts is not None:
                if not isinstance(message_parts, list):
                    self._send(400, {"error": "message_parts must be a list"})
                    return
                # Validate parts format and size
                total_parts_bytes = 0
                for p in message_parts:
                    if not isinstance(p, dict) or "type" not in p:
                        self._send(400, {"error": "Each message part must be a dict with 'type'"})
                        return
                    ptype = p.get("type")
                    if ptype == "text":
                        t = p.get("text", "")
                        if not isinstance(t, str):
                            self._send(400, {"error": "Part type text requires string 'text'"})
                            return
                        total_parts_bytes += len(t.encode("utf-8"))
                    elif ptype == "image_url":
                        iu = p.get("image_url", {})
                        if not isinstance(iu, dict) or "url" not in iu or not isinstance(iu.get("url"), str):
                            self._send(400, {"error": "Part type image_url requires dict with 'url' string"})
                            return
                        url_val = iu.get("url", "")
                        if not url_val.strip():
                            self._send(400, {"error": "Part image_url url cannot be empty"})
                            return
                        total_parts_bytes += len(url_val.encode("utf-8"))
                    else:
                        self._send(400, {"error": f"Unsupported message part type: {ptype}"})
                        return
                if total_parts_bytes > 2 * 1024 * 1024:
                    self._send(400, {"error": "message_parts size exceeds 2MB limit"})
                    return
                db_user_content = json.dumps(message_parts, ensure_ascii=False)

            model = req_json.get("model", "gpt-4o")
            client_effort = req_json.get("reasoning_effort")
            if client_effort not in (None, "") and client_effort not in cloud_bots.EFFORTS:
                self._send(400, {"error": "reasoning_effort must be one of off/low/medium/high/xhigh"})
                return
            client_nonce = req_json.get("client_nonce")
            provider_req = req_json.get("provider", {})
            bot = session_bot(sid)
            if bot and bot.get("model") and bot.get("credential"):
                # Bot 自带模型选择：覆盖客户端当前模型
                model = bot["model"]
                provider_req = {"protocol": "chat", "credential": bot["credential"]}

            provider, p_status, p_err = resolve_provider(provider_req)
            if p_err:
                self._send(p_status, {"error": p_err})
                return

            conn = get_db_connection()
            c = conn.cursor()
            try:
                c.execute("BEGIN IMMEDIATE")
                c.execute("SELECT session_id, instructions FROM sessions WHERE session_id = ?", (sid,))
                s_row = c.fetchone()
                if not s_row:
                    conn.rollback()
                    conn.close()
                    self._send(404, {"error": "Session not found"})
                    return
                
                instructions = req_json.get("instructions") or s_row[1] or "You are OpenMinis Cloud Agent."

                # Check client_nonce idempotency
                if client_nonce:
                    c.execute("SELECT task_id, status FROM tasks WHERE client_nonce = ? AND session_id = ?", (client_nonce, sid))
                    existing_task = c.fetchone()
                    if existing_task:
                        conn.rollback()
                        conn.close()
                        self._send(200, {"task_id": existing_task[0], "session_id": sid, "status": existing_task[1], "idempotent_replayed": True})
                        return

                try:
                    GATE.check_capacity(task_lane(sid), session_persona_id(sid))
                except iso.QueueFull as e:
                    conn.rollback()
                    conn.close()
                    self._send(429, {"error": str(e)})
                    return
                c.execute("SELECT task_id FROM tasks WHERE session_id = ? AND status IN ('running', 'waiting_user')", (sid,))
                running = c.fetchone()
                if running:
                    conn.rollback()
                    conn.close()
                    self._send(409, {"error": "Conflict: Session has a running task", "running_task_id": running[0]})
                    return

                tid = "task_" + uuid.uuid4().hex[:12]
                created_at = time.time()
                c.execute(
                    "INSERT INTO tasks (task_id, session_id, client_nonce, status, model, created_at) VALUES (?, ?, ?, 'running', ?, ?)",
                    (tid, sid, client_nonce, model, created_at)
                )
                c.execute("INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, 'user', ?, ?)", (sid, db_user_content, created_at))
                conn.commit()
            except sqlite3.IntegrityError:
                conn.rollback()
                conn.close()
                self._send(409, {"error": "Conflict: Session already has a running task or nonce collision"})
                return
            except Exception as e:
                conn.rollback()
                conn.close()
                self._send(500, {"error": str(e)})
                return
            finally:
                try:
                    conn.close()
                except Exception:
                    pass

            with active_tasks_lock:
                active_tasks[tid] = {"process": None, "cancelled": False, "pid": None}
            if client_effort and not (bot and bot.get("reasoning_effort")):
                TASK_EFFORT[tid] = client_effort

            # Start background thread BEFORE sending HTTP 202 to guarantee execution survives client disconnect
            task_thread = threading.Thread(
                target=run_agent_task,
                args=(tid, sid, content, model, provider, instructions),
                daemon=True
            )
            task_thread.start()
            
            try:
                self._send(202, {"task_id": tid, "session_id": sid, "status": "running"})
            except Exception:
                # BrokenPipeError / Client disconnected immediately after sending - task is already running!
                pass
            return

        if path == "/v1/notify/test":
            cfg = current_notify_config()
            if not cfg:
                self._send(404, {"error": "Notification not configured"})
                return
            ok, err = cloud_notify.send_now(cfg, "OpenMinis 云电脑", "推送测试：收到这条说明配置正确。", event="test")
            self._send(200 if ok else 502, {"ok": ok, "error": err})
            return

        if path == "/v1/skills/sync":
            conn = get_db_connection()
            try:
                counts = cloud_skills.sync(conn, req_json.get("skills"), prune=bool(req_json.get("prune")))
            except ValueError as e:
                self._send(400, {"error": str(e)})
                return
            finally:
                conn.close()
            self._send(200, counts)
            return

        if path == "/v1/memory":
            conn = get_db_connection()
            try:
                entry, created = cloud_memory.write(conn, req_json.get("content"), req_json.get("category"), source=req_json.get("source") if req_json.get("source") in ("phone", "cloud") else "phone")
            except ValueError as e:
                self._send(400, {"error": str(e)})
                return
            finally:
                conn.close()
            self._send(201 if created else 200, dict(entry, created=created))
            return

        if path == "/v1/routines":
            try:
                fields = validate_routine_fields(req_json)
            except ValueError as e:
                self._send(400, {"error": str(e)})
                return
            self._send(201, create_routine(fields))
            return

        if path.startswith("/v1/routines/") and path.endswith("/run"):
            parts = path.split("/")
            rid = parts[3] if len(parts) == 5 else ""
            routine = get_routine(rid) if ROUTINE_ID_RE.match(rid) else None
            if not routine:
                self._send(404, {"error": "Routine not found"})
                return
            run = launch_routine_run(routine, "manual")
            self._send(202 if run["status"] == "running" else 200, run)
            return

        if path.startswith("/v1/tasks/") and "/approvals/" in path:
            parts = path.split("/")
            if len(parts) != 6 or parts[4] != "approvals":
                self._send(404, {"error": "Not found"})
                return
            tid, aid = parts[3], parts[5]
            decision = req_json.get("decision")
            if decision not in ("approve", "deny"):
                self._send(400, {"error": "decision must be 'approve' or 'deny'"})
                return
            note = req_json.get("note")
            if note is not None and (not isinstance(note, str) or len(note) > 1000):
                self._send(400, {"error": "note must be a string (max 1000)"})
                return
            code, body = resolve_approval(tid, aid, "approved" if decision == "approve" else "denied", note)
            self._send(code, body)
            return

        if path.startswith("/v1/tasks/") and path.endswith("/cancel"):
            parts = path.split("/")
            tid = parts[3] if len(parts) >= 4 else ""
            conn = get_db_connection()
            c = conn.cursor()
            c.execute("SELECT status FROM tasks WHERE task_id = ?", (tid,))
            r = c.fetchone()
            if not r:
                conn.close()
                self._send(404, {"error": "Task not found"})
                return
            if r[0] in ["completed", "failed", "cancelled", "limit_reached", "interrupted"]:
                conn.close()
                self._send(200, {"task_id": tid, "status": r[0]})
                return
            set_task_cancelled(tid)
            c.execute("UPDATE tasks SET status = 'cancelled' WHERE task_id = ? AND status IN ('running', 'waiting_user')", (tid,))
            conn.commit()
            conn.close()
            log_event(tid, "cancelled", {"message": "Cancelled via API"})
            self._send(200, {"task_id": tid, "status": "cancelled"})
            return

        self._send(404, {"error": "Not found"})

    def log_message(self, format, *args):
        pass

CloudAgentHandler = Handler

def warm_browser():
    """资源设置开启预热时，启动后先把共享浏览器开好，第一次网页操作不用等冷启动。"""
    if not resource_settings().get("browser_warm") or not cloud_browser.is_browser_available():
        return
    os.makedirs(SHARED_WORKSPACE, exist_ok=True)
    res = cloud_browser.execute_browser_action("shared", SHARED_WORKSPACE, {"action": "__warm__"})
    print(f"[startup] browser warm: {res}", flush=True)

def run_server():
    global SERVER_TOKEN
    if not SERVER_TOKEN:
        SERVER_TOKEN = validate_and_load_token()
    server = ThreadingHTTPServer((HOST, PORT), Handler)

    def start_background():
        # 后台服务（定时任务、Telegram 长轮询）放在独立线程启动：任何一项出错或网络不通都不影响 /health 与 API 立即可用
        for name, fn in (("scheduler", start_scheduler), ("telegram", start_telegram), ("browser-warm", warm_browser)):
            try:
                fn()
            except Exception as e:
                print(f"[startup] {name} failed to start: {type(e).__name__}: {e}", flush=True)

    threading.Thread(target=start_background, name="startup-background", daemon=True).start()
    print(f"OpenMinis Cloud Computer & Agent running on {HOST}:{PORT}", flush=True)
    server.serve_forever()

if __name__ == "__main__":
    run_server()
